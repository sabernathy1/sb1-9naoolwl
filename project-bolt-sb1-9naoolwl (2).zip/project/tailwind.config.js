/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#fff1f6',
          100: '#ffe4ed',
          200: '#ffc9dc',
          300: '#ff9dbe',
          400: '#ff619b',
          500: '#ff3379', // Main pink from logo
          600: '#ea1d61',
          700: '#c4124d',
          800: '#a11442',
          900: '#85133c',
          950: '#4c0620',
        },
        gray: {
          50: '#f8f8f8',
          100: '#f0f0f0',
          200: '#e4e4e4',
          300: '#d1d1d1',
          400: '#b4b4b4',
          500: '#9a9a9a', // Main gray from logo
          600: '#818181',
          700: '#6a6a6a',
          800: '#5a5a5a',
          900: '#4e4e4e',
          950: '#282828',
        }
      },
      fontFamily: {
        sans: ['Inter var', 'sans-serif'],
        display: ['Playfair Display', 'serif'], // For "Perfection" text styling
      },
    },
  },
  plugins: [],
};