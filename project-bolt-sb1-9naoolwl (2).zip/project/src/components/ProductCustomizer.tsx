import React, { useEffect, useRef, useCallback, useState } from 'react';
import { fabric } from 'fabric';
import { useDropzone } from 'react-dropzone';
import { ImageIcon, RotateCw, Trash2, Shirt, Check } from 'lucide-react';

type DesignPlacement = 'front' | 'back' | 'left-sleeve' | 'right-sleeve';

interface ProductCustomizerProps {
  productViews: Record<string, string | null>;
  onDesignChange: (designs: Record<DesignPlacement, string | null>) => void;
  availablePlacements?: string[];
  onPlacementsChange?: (placements: string[]) => void;
}

const CANVAS_SIZE = 400;

const ProductCustomizer: React.FC<ProductCustomizerProps> = ({
  productViews,
  onDesignChange,
  availablePlacements = ['front', 'back', 'left-sleeve', 'right-sleeve'],
  onPlacementsChange = () => {}
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const mountedRef = useRef(true);
  const canvasesRef = useRef<Record<string, fabric.Canvas>>({});
  const designsRef = useRef<Record<DesignPlacement, string | null>>({
    front: null,
    back: null,
    'left-sleeve': null,
    'right-sleeve': null,
  });

  const [selectedPlacements, setSelectedPlacements] = useState<string[]>([]);
  const [activeCanvas, setActiveCanvas] = useState<string | null>(null);
  const [selectedObject, setSelectedObject] = useState<fabric.Object | null>(null);
  const [loadingBackground, setLoadingBackground] = useState(false);

  const handlePlacementChange = (placement: string) => {
    setSelectedPlacements(prev => {
      const newPlacements = prev.includes(placement)
        ? prev.filter(p => p !== placement)
        : [...prev, placement];
      onPlacementsChange(newPlacements);
      return newPlacements;
    });
  };

  const cleanupCanvas = useCallback(() => {
    Object.values(canvasesRef.current).forEach(canvas => {
      if (canvas) {
        canvas.off();
        canvas.clear();
        canvas.dispose();
      }
    });
    canvasesRef.current = {};
    setSelectedObject(null);
  }, []);

  const updateDesigns = useCallback((canvas: fabric.Canvas, placement: string) => {
    if (!canvas || !mountedRef.current) return;
    
    try {
      const currentDesign = canvas.toDataURL({
        format: 'png',
        quality: 1,
        multiplier: 1,
      });
      
      designsRef.current[placement as DesignPlacement] = currentDesign;
      onDesignChange(designsRef.current);
    } catch (error) {
      console.error('Error updating designs:', error);
    }
  }, [onDesignChange]);

  const loadBackgroundImage = useCallback(async (canvas: fabric.Canvas, url: string) => {
    if (!canvas || !mountedRef.current) return;
    
    setLoadingBackground(true);
    try {
      return new Promise<void>((resolve) => {
        fabric.Image.fromURL(
          url,
          (img) => {
            if (!canvas || !mountedRef.current) return;
            
            const scale = Math.min(
              canvas.width! / img.width!,
              canvas.height! / img.height!
            ) * 0.9;
            
            img.set({
              scaleX: scale,
              scaleY: scale,
              left: (canvas.width! - img.width! * scale) / 2,
              top: (canvas.height! - img.height! * scale) / 2,
              selectable: false,
              evented: false,
            });
            
            canvas.setBackgroundImage(img, () => {
              if (canvas && mountedRef.current) {
                canvas.renderAll();
                resolve();
              }
            });
          },
          {
            crossOrigin: 'anonymous',
            erasable: false
          }
        );
      });
    } catch (error) {
      console.error('Error loading background image:', error);
    } finally {
      if (mountedRef.current) {
        setLoadingBackground(false);
      }
    }
  }, []);

  const initCanvas = useCallback(async (placement: string) => {
    if (!containerRef.current || !mountedRef.current) return;

    try {
      // Create canvas element
      const canvasEl = document.createElement('canvas');
      canvasEl.width = CANVAS_SIZE;
      canvasEl.height = CANVAS_SIZE;

      // Create wrapper for proper sizing
      const wrapper = document.createElement('div');
      wrapper.style.width = '100%';
      wrapper.style.height = '100%';
      wrapper.style.display = 'flex';
      wrapper.style.alignItems = 'center';
      wrapper.style.justifyContent = 'center';
      wrapper.style.backgroundColor = '#f8f8f8';
      wrapper.style.borderRadius = '0.5rem';

      const canvasContainer = document.createElement('div');
      canvasContainer.style.width = `${CANVAS_SIZE}px`;
      canvasContainer.style.height = `${CANVAS_SIZE}px`;
      canvasContainer.style.position = 'relative';

      canvasContainer.appendChild(canvasEl);
      wrapper.appendChild(canvasContainer);

      // Safely clear and update container
      if (containerRef.current) {
        while (containerRef.current.firstChild) {
          containerRef.current.removeChild(containerRef.current.firstChild);
        }
        containerRef.current.appendChild(wrapper);
      }

      // Wait for DOM update
      await new Promise(resolve => setTimeout(resolve, 0));

      if (!mountedRef.current) return;

      // Initialize Fabric canvas
      const canvas = new fabric.Canvas(canvasEl, {
        width: CANVAS_SIZE,
        height: CANVAS_SIZE,
        backgroundColor: '#ffffff',
        preserveObjectStacking: true,
        selection: true,
        allowTouchScrolling: true,
      });

      canvasesRef.current[placement] = canvas;
      setActiveCanvas(placement);

      // Set up event listeners
      canvas.on('selection:created', (e) => setSelectedObject(e.selected?.[0] || null));
      canvas.on('selection:cleared', () => setSelectedObject(null));
      canvas.on('object:modified', () => updateDesigns(canvas, placement));
      canvas.on('object:added', () => updateDesigns(canvas, placement));
      canvas.on('object:removed', () => updateDesigns(canvas, placement));

      // Load background image
      if (productViews[placement]) {
        await loadBackgroundImage(canvas, productViews[placement]!);
      }
    } catch (error) {
      console.error('Error initializing canvas:', error);
      cleanupCanvas();
    }
  }, [productViews, cleanupCanvas, loadBackgroundImage, updateDesigns]);

  const { getRootProps, getInputProps } = useDropzone({
    accept: {
      'image/*': []
    },
    onDrop: useCallback(async (acceptedFiles: File[]) => {
      if (!activeCanvas || !canvasesRef.current[activeCanvas]) return;

      const file = acceptedFiles[0];
      if (!file) return;

      try {
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });

        const canvas = canvasesRef.current[activeCanvas];
        if (!canvas || !mountedRef.current) return;

        fabric.Image.fromURL(dataUrl, (img) => {
          if (!canvas || !mountedRef.current) return;

          const scale = Math.min(
            (CANVAS_SIZE * 0.8) / img.width!,
            (CANVAS_SIZE * 0.8) / img.height!
          );

          img.scale(scale);
          img.set({
            left: (CANVAS_SIZE - img.width! * scale) / 2,
            top: (CANVAS_SIZE - img.height! * scale) / 2
          });

          canvas.add(img);
          canvas.setActiveObject(img);
          canvas.renderAll();
          updateDesigns(canvas, activeCanvas);
        });
      } catch (error) {
        console.error('Error adding image:', error);
      }
    }, [activeCanvas, updateDesigns])
  });

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      cleanupCanvas();
    };
  }, [cleanupCanvas]);

  useEffect(() => {
    if (selectedPlacements.length > 0 && !activeCanvas) {
      initCanvas(selectedPlacements[0]);
    }
  }, [selectedPlacements, activeCanvas, initCanvas]);

  useEffect(() => {
    if (activeCanvas && productViews[activeCanvas]) {
      const canvas = canvasesRef.current[activeCanvas];
      if (canvas) {
        loadBackgroundImage(canvas, productViews[activeCanvas]!);
      }
    }
  }, [activeCanvas, productViews, loadBackgroundImage]);

  return (
    <div className="space-y-6">
      {/* Placement Selection */}
      <div className="flex flex-wrap gap-2">
        {availablePlacements.map((placement) => (
          <button
            key={placement}
            onClick={() => handlePlacementChange(placement)}
            className={`p-2 rounded-md flex items-center gap-2 ${
              selectedPlacements.includes(placement)
                ? 'bg-primary-100 text-primary-600'
                : 'hover:bg-gray-100'
            }`}
          >
            <Shirt className="w-5 h-5" />
            <span className="text-sm capitalize">{placement.replace('-', ' ')}</span>
            {designsRef.current[placement as DesignPlacement] && (
              <Check className="w-4 h-4 text-green-500" />
            )}
          </button>
        ))}
      </div>

      {/* Canvas Container */}
      <div
        ref={containerRef}
        className="relative border rounded-lg bg-gray-50 overflow-hidden"
        style={{ width: '100%', minHeight: CANVAS_SIZE, maxWidth: '100%' }}
      >
        {loadingBackground && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-50 bg-opacity-75 z-10">
            <div className="animate-spin rounded-full h-8 w-8 border-2 border-primary-600 border-t-transparent" />
          </div>
        )}
      </div>

      {selectedPlacements.length > 0 && (
        <div className="space-y-6">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
            <div {...getRootProps()} className="cursor-pointer text-center">
              <input {...getInputProps()} />
              <ImageIcon className="w-8 h-8 mx-auto mb-2 text-gray-400" />
              <p className="text-sm text-gray-600">
                Drag & drop an image here, or click to select
              </p>
            </div>
          </div>

          {selectedObject && (
            <div className="flex flex-wrap gap-2 justify-center">
              <button
                onClick={() => {
                  if (!selectedObject || !activeCanvas) return;
                  const canvas = canvasesRef.current[activeCanvas];
                  if (!canvas) return;
                  selectedObject.rotate((selectedObject.angle || 0) + 90);
                  canvas.requestRenderAll();
                  updateDesigns(canvas, activeCanvas);
                }}
                className="p-2 hover:bg-gray-100 rounded-md"
                title="Rotate"
              >
                <RotateCw className="w-5 h-5" />
              </button>
              <button
                onClick={() => {
                  if (!selectedObject || !activeCanvas) return;
                  const canvas = canvasesRef.current[activeCanvas];
                  if (!canvas) return;
                  canvas.remove(selectedObject);
                  canvas.requestRenderAll();
                  updateDesigns(canvas, activeCanvas);
                }}
                className="p-2 hover:bg-gray-100 rounded-md text-red-600"
                title="Delete"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ProductCustomizer;