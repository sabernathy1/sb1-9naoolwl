import React, { useState, useEffect } from "react";
import { getLogoUrl } from "../lib/supabase-storage";

const Footer: React.FC = () => {
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [logoError, setLogoError] = useState(false);

  useEffect(() => {
    const loadLogo = async () => {
      try {
        const url = getLogoUrl();
        // Check if image loads successfully
        const img = new Image();
        img.onload = () => setLogoUrl(url);
        img.onerror = () => setLogoError(true);
        img.src = url;
      } catch (error) {
        console.error('Error loading logo:', error);
        setLogoError(true);
      }
    };
    loadLogo();
  }, []);

  return (
    <footer className="bg-gray-900 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center">
          <div className="flex items-center gap-4 mb-4">
            {!logoError && logoUrl && (
              <img 
                src={logoUrl}
                alt="Personalized Perfection" 
                className="h-16 w-auto"
                onError={() => setLogoError(true)}
              />
            )}
            <div className="flex flex-col">
              <span className="text-2xl font-display font-bold bg-gradient-to-r from-primary-400 to-primary-600 bg-clip-text text-transparent">
                Personalized
              </span>
              <span className="text-xl text-gray-300">Perfection</span>
            </div>
          </div>
          <p className="text-gray-400 text-sm text-center">
            You think it, we make it.
          </p>
          <p className="mt-6 text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} Personalized Perfection. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;