import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ShoppingCart, User } from "lucide-react";
import { useCartStore } from "../store/cartStore";
import { getLogoUrl } from "../lib/supabase-storage";

const Navbar: React.FC = () => {
  const items = useCartStore((state) => state.items);
  const itemCount = items.reduce((total, item) => total + item.quantity, 0);
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [logoError, setLogoError] = useState(false);

  useEffect(() => {
    const loadLogo = async () => {
      try {
        const url = getLogoUrl();
        const img = new Image();
        img.onload = () => setLogoUrl(url);
        img.onerror = () => setLogoError(true);
        img.src = url;
      } catch (error) {
        console.error('Error loading logo:', error);
        setLogoError(true);
      }
    };
    loadLogo();
  }, []);

  return (
    <>
      <div className="bg-primary-600 text-white py-2 px-4 text-center text-sm">
        <p>
          🎉 SPECIAL OFFER: 20% off bulk orders of 5+ apparel items! Plus, FREE shipping on orders over $50!
        </p>
      </div>
      <nav className="bg-gray-900 text-white p-4 shadow-lg">
        <div className="container mx-auto flex justify-between items-center">
          <Link to="/" className="flex items-center gap-4">
            {!logoError && logoUrl && (
              <img 
                src={logoUrl}
                alt="Personalized Perfection" 
                className="h-12 w-auto"
                onError={() => setLogoError(true)}
              />
            )}
            <div className="flex flex-col">
              <span className="text-2xl font-display font-bold bg-gradient-to-r from-primary-400 to-primary-600 bg-clip-text text-transparent">
                Personalized
              </span>
              <span className="text-xl text-gray-300">Perfection</span>
            </div>
          </Link>
          <div className="flex items-center space-x-6">
            <ul className="flex space-x-6">
              <li>
                <Link to="/" className="hover:text-primary-400 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:text-primary-400 transition-colors">
                  Services
                </Link>
              </li>
              <li>
                <Link to="/shop" className="hover:text-primary-400 transition-colors">
                  Shop
                </Link>
              </li>
              <li>
                <Link to="/gallery" className="hover:text-primary-400 transition-colors">
                  Gallery
                </Link>
              </li>
            </ul>
            <div className="flex items-center space-x-4 ml-6">
              <Link to="/cart" className="hover:text-primary-400 transition-colors relative">
                <ShoppingCart className="w-6 h-6" />
                {itemCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-primary-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {itemCount}
                  </span>
                )}
              </Link>
              <Link to="/account" className="hover:text-primary-400 transition-colors">
                <User className="w-6 h-6" />
              </Link>
            </div>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Navbar;