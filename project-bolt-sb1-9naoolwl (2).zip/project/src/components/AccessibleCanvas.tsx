import React, { KeyboardEvent } from 'react';
import { fabric } from 'fabric';

interface AccessibleCanvasProps {
  canvas: fabric.Canvas | null;
  children: React.ReactNode;
}

export const AccessibleCanvas: React.FC<AccessibleCanvasProps> = ({ canvas, children }) => {
  const handleKeyboardControls = (e: KeyboardEvent) => {
    if (!canvas) return;

    const activeObject = canvas.getActiveObject();
    if (!activeObject) return;

    const MOVE_DISTANCE = 1;
    const FAST_MOVE_DISTANCE = 10;

    switch (e.key) {
      case 'ArrowLeft':
        activeObject.left! -= e.shiftKey ? FAST_MOVE_DISTANCE : MOVE_DISTANCE;
        break;
      case 'ArrowRight':
        activeObject.left! += e.shiftKey ? FAST_MOVE_DISTANCE : MOVE_DISTANCE;
        break;
      case 'ArrowUp':
        activeObject.top! -= e.shiftKey ? FAST_MOVE_DISTANCE : MOVE_DISTANCE;
        break;
      case 'ArrowDown':
        activeObject.top! += e.shiftKey ? FAST_MOVE_DISTANCE : MOVE_DISTANCE;
        break;
      case 'Delete':
      case 'Backspace':
        canvas.remove(activeObject);
        break;
      case 'r':
        if (e.ctrlKey || e.metaKey) {
          activeObject.rotate((activeObject.angle || 0) + 90);
        }
        break;
      default:
        return;
    }

    activeObject.setCoords();
    canvas.renderAll();
    e.preventDefault();
  };

  return (
    <div
      role="application"
      aria-label="Product customization canvas"
      tabIndex={0}
      onKeyDown={handleKeyboardControls}
      className="focus:outline-none focus:ring-2 focus:ring-primary-500 rounded-lg"
    >
      {children}
    </div>
  );
};