import React, { useState, useEffect } from 'react';
import { ServiceProduct, ServiceOptionGroup, ServiceOption } from '../types';
import { ArrowRight } from 'lucide-react';

interface ServiceProductFormProps {
  product: ServiceProduct;
  onSubmit: (selection: { options: Record<string, string> }) => void;
}

const ServiceProductForm: React.FC<ServiceProductFormProps> = ({ product, onSubmit }) => {
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>({});
  const [totalPrice, setTotalPrice] = useState(product.base_price);

  useEffect(() => {
    // Initialize with default (first) options
    const defaults: Record<string, string> = {};
    product.options.forEach(group => {
      if (group.required && group.options.length > 0) {
        defaults[group.name] = group.options[0].value;
      }
    });
    setSelectedOptions(defaults);
  }, [product]);

  useEffect(() => {
    // Calculate total price based on selected options
    let total = product.base_price;
    
    Object.entries(selectedOptions).forEach(([groupName, selectedValue]) => {
      const group = product.options.find(g => g.name === groupName);
      if (group) {
        const option = group.options.find(o => o.value === selectedValue);
        if (option) {
          total += option.price;
        }
      }
    });
    
    setTotalPrice(total);
  }, [selectedOptions, product]);

  const handleOptionChange = (groupName: string, value: string) => {
    setSelectedOptions(prev => ({
      ...prev,
      [groupName]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ options: selectedOptions });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {product.options.map((group: ServiceOptionGroup) => (
        <div key={group.name}>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {group.name}
            {group.required && <span className="text-red-500 ml-1">*</span>}
          </label>
          <select
            value={selectedOptions[group.name] || ''}
            onChange={(e) => handleOptionChange(group.name, e.target.value)}
            required={group.required}
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
          >
            {group.options.map((option: ServiceOption) => (
              <option key={option.value} value={option.value}>
                {option.label} {option.price > 0 ? `(+$${option.price.toFixed(2)})` : ''}
              </option>
            ))}
          </select>
        </div>
      ))}

      <div className="border-t pt-4">
        <div className="flex justify-between items-center mb-4">
          <span className="text-gray-600">Base Price:</span>
          <span>${product.base_price.toFixed(2)}</span>
        </div>
        <div className="flex justify-between items-center text-lg font-bold">
          <span>Total Price:</span>
          <span>${totalPrice.toFixed(2)}</span>
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-primary-600 text-white py-3 px-6 rounded-lg hover:bg-primary-700 transition duration-300 flex items-center justify-center gap-2"
      >
        Book Now
        <ArrowRight className="w-5 h-5" />
      </button>
    </form>
  );
};

export default ServiceProductForm;