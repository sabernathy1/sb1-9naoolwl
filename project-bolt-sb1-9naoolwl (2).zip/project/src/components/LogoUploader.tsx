import React, { useState } from 'react';
import { uploadLogo } from '../lib/supabase-storage';
import toast from 'react-hot-toast';

const LogoUploader: React.FC = () => {
  const [uploading, setUploading] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const publicUrl = await uploadLogo(file);
      toast.success('Logo uploaded successfully!');
      // Force reload to show new logo
      window.location.reload();
    } catch (error) {
      console.error('Error uploading logo:', error);
      toast.error('Failed to upload logo');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="p-4 border rounded-lg">
      <h3 className="text-lg font-semibold mb-2">Upload Logo</h3>
      <input
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        disabled={uploading}
        className="block w-full text-sm text-gray-500
          file:mr-4 file:py-2 file:px-4
          file:rounded-full file:border-0
          file:text-sm file:font-semibold
          file:bg-primary-50 file:text-primary-700
          hover:file:bg-primary-100"
      />
      {uploading && <p className="mt-2 text-sm text-gray-600">Uploading...</p>}
    </div>
  );
};

export default LogoUploader;