import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { supabase } from '../lib/supabase';
import { ServiceProduct } from '../types';
import ServiceProductForm from '../components/ServiceProductForm';
import { 
  Printer, 
  PenTool, 
  ShoppingCart, 
  Palette, 
  Clock,
  Check,
  Loader
} from 'lucide-react';
import toast from 'react-hot-toast';

const services = {
  'press-only': {
    title: 'Bring Your Vision to Life—Pressed Perfectly!',
    icon: <Printer className="w-24 h-24 text-primary-600" />,
    image: 'https://images.unsplash.com/photo-1622557850710-d08a111d3476?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1622557850710-d08a111d3476?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1589782182703-2aaa69037b5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1618556450994-a6a128ef0d9d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    description: "Got a design and an item you want it placed on, but don't have the tools to do it yourself? That's where we come in!",
    features: [
      'On-Site Service: We come to you',
      'Quick Turnaround Service',
      'Professional Equipment',
      'Expert Application'
    ],
    pricing: [
      { name: 'Basic Press (Single Location)', price: '15.00' },
      { name: 'Multi-Location Press', price: '25.00' },
      { name: 'On-Site Service (Within 20 miles)', price: '50.00' },
      { name: 'Rush Service (Same Day)', price: '30.00' }
    ],
    process: [
      'Schedule your service time and location',
      'Prepare your items and designs',
      'Our team arrives with professional equipment',
      'Expert application of your designs',
      'Quality check and finishing'
    ],
    faq: [
      {
        question: 'What types of items can you press?',
        answer: 'We can press designs onto t-shirts, hoodies, bags, caps, and most fabric items. Contact us for specific requirements.'
      },
      {
        question: 'How long does the process take?',
        answer: 'Most single-item pressings take 15-30 minutes. Multiple items or complex designs may take longer.'
      },
      {
        question: 'Do you provide design services?',
        answer: 'While this service is for pressing only, we offer full design services in our Design & Press package.'
      }
    ]
  },
  'design-shop': {
    title: 'Design, Shop, Create—All in One Place',
    icon: <PenTool className="w-24 h-24 text-primary-600" />,
    image: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1558655146-9f40138edfeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1560421683-6856ea585c78?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1561070791-2526d30994b5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    description: "Unleash your creativity with our design and shop experience! Share your vision, explore our collection, and we'll handle the rest.",
    features: [
      'Professional Design Service',
      'Premium Blank Selection',
      'Quality Printing',
      'Expert Pressing'
    ],
    pricing: [
      { name: 'Basic Design Package', price: '49.99' },
      { name: 'Custom Design Service (Per Hour)', price: '75.00' },
      { name: 'Rush Design Service', price: '99.99' },
      { name: 'Revisions (Per Round)', price: '25.00' }
    ],
    process: [
      'Initial design consultation',
      'Browse and select blank items',
      'Professional design creation',
      'Design review and revisions',
      'Production and quality check'
    ],
    faq: [
      {
        question: 'How many revisions are included?',
        answer: 'Two rounds of revisions are included in the basic design package. Additional revisions are available for a fee.'
      },
      {
        question: 'What file formats do you accept?',
        answer: 'We accept AI, PSD, PDF, and high-resolution JPG/PNG files. We can also work from sketches or descriptions.'
      },
      {
        question: 'How long does the design process take?',
        answer: 'Most designs are completed within 2-3 business days. Rush service is available for same-day or next-day delivery.'
      }
    ]
  },
  'print-press': {
    title: 'Your Design, Perfectly Pressed',
    icon: <ShoppingCart className="w-24 h-24 text-primary-600" />,
    image: 'https://images.unsplash.com/photo-1618004912476-29818d81ae2e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1618004912476-29818d81ae2e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1618556450994-a6a128ef0d9d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Got a ready-to-print design and the perfect canvas? Let us handle the rest with precision and care.',
    features: [
      'Next-Day Service Available',
      'Same-Day Options',
      'Professional Quality',
      'Multiple Item Orders'
    ],
    pricing: [
      { name: 'Single Item Press', price: '20.00' },
      { name: 'Bulk Order (10+ items)', price: '15.00' },
      { name: 'Same-Day Service', price: '35.00' },
      { name: 'Additional Locations', price: '10.00' }
    ],
    process: [
      'Submit your design files',
      'Choose printing specifications',
      'Production setup',
      'Quality check',
      'Finishing and packaging'
    ],
    faq: [
      {
        question: 'What are your file requirements?',
        answer: 'We accept vector files (AI, EPS) or high-resolution (300dpi) PNG/JPG files. Designs should be in the correct size and color mode.'
      },
      {
        question: 'How quickly can I get my order?',
        answer: 'Standard turnaround is 2-3 business days. Same-day and next-day services are available for an additional fee.'
      },
      {
        question: 'Do you offer bulk discounts?',
        answer: 'Yes! Orders of 10 or more items receive a discount. Plus, orders of 5+ apparel items get an additional 20% off!'
      }
    ]
  },
  'design-press': {
    title: 'Your Canvas, Your Vision, Our Expertise',
    icon: <Palette className="w-24 h-24 text-primary-600" />,
    image: 'https://images.unsplash.com/photo-1621600411688-4be93cd68504?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1621600411688-4be93cd68504?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1613979813687-3d1b187a7e35?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1618556658017-fd9c732d1360?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    description: "Bring us your blank canvas and let's create something extraordinary together!",
    features: [
      'Collaborative Design Process',
      'Expert Design Assistance',
      'Professional Printing',
      'Quality Pressing'
    ],
    pricing: [
      { name: 'Design Consultation', price: '49.99' },
      { name: 'Custom Design Creation', price: '99.99' },
      { name: 'Premium Design Package', price: '149.99' },
      { name: 'Rush Service', price: '49.99' }
    ],
    process: [
      'Initial consultation and concept discussion',
      'Design creation and mockups',
      'Review and revisions',
      'Final design approval',
      'Production and quality check'
    ],
    faq: [
      {
        question: 'What does the design process involve?',
        answer: "We start with a consultation to understand your vision, create initial designs, and work with you through revisions until you're completely satisfied."
      },
      {
        question: 'How long does it take?',
        answer: 'The design process typically takes 3-5 business days, depending on complexity and revisions. Rush service is available.'
      },
      {
        question: 'Can I see a mockup before printing?',
        answer: 'Yes! We provide digital mockups of your design on the selected items before proceeding with production.'
      }
    ]
  },
  'print-shop': {
    title: 'Print Ready, Shop Smart',
    icon: <Clock className="w-24 h-24 text-primary-600" />,
    image: 'https://images.unsplash.com/photo-1513346940221-6f673d962e97?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1513346940221-6f673d962e97?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1589782182703-2aaa69037b5b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1620799140188-3b2a02fd9a77?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Browse our premium blanks and let us bring your ready-to-print designs to life with professional quality printing.',
    features: [
      'Premium Blank Selection',
      'Next-Day Service',
      'Bulk Order Options',
      'Quality Guaranteed'
    ],
    pricing: [
      { name: 'Standard Print Service', price: '25.00' },
      { name: 'Bulk Printing (10+ items)', price: '20.00' },
      { name: 'Rush Service', price: '40.00' },
      { name: 'Additional Locations', price: '15.00' }
    ],
    process: [
      'Select your blank items',
      'Upload your print-ready design',
      'Choose printing specifications',
      'Production and quality check',
      'Packaging and delivery'
    ],
    faq: [
      {
        question: 'What blank items do you offer?',
        answer: 'We offer a wide range of premium blanks including t-shirts, hoodies, caps, bags, and more. All items are high-quality and carefully selected.'
      },
      {
        question: 'What are your printing methods?',
        answer: 'We use heat transfer, direct-to-garment (DTG), and vinyl printing depending on your design and requirements.'
      },
      {
        question: 'Do you offer samples?',
        answer: 'Yes! You can order blank samples or request a sample print of your design for a small fee.'
      }
    ]
  }
};

const ServiceDetails = () => {
  const { serviceId } = useParams();
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState<ServiceProduct[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<ServiceProduct | null>(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const { data, error } = await supabase
          .from('service_products')
          .select('*')
          .eq('service_id', serviceId);

        if (error) throw error;

        setProducts(data || []);
        if (data && data.length > 0) {
          setSelectedProduct(data[0]);
        }
      } catch (error) {
        console.error('Error fetching service products:', error);
        toast.error('Failed to load service options');
      } finally {
        setLoading(false);
      }
    };

    if (serviceId) {
      fetchProducts();
    }
  }, [serviceId]);

  const service = services[serviceId];

  if (!service) {
    return (
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold">Service not found</h1>
        <Link to="/services" className="text-primary-600 hover:text-primary-700">
          Return to Services
        </Link>
      </div>
    );
  }

  const handleProductSubmit = (selection: { options: Record<string, string> }) => {
    if (!selectedProduct) return;
    
    console.log('Service booked:', {
      product: selectedProduct,
      selection
    });
    
    toast.success('Service added to cart!');
  };

  return (
    <>
      <Helmet>
        <title>{service.title} - Perfectly Personalized</title>
        <meta name="description" content={service.description} />
      </Helmet>

      <div className="relative bg-primary-900 text-white">
        <div className="absolute inset-0">
          <img 
            src={service.image} 
            alt={service.title}
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-primary-900/60 mix-blend-multiply" />
        </div>
        
        <div className="relative container mx-auto px-4 py-24">
          <div className="flex flex-col items-center">
            {service.icon}
            <h1 className="text-4xl font-bold text-center mt-6 mb-4">{service.title}</h1>
            <p className="text-xl text-primary-100 text-center max-w-2xl">
              {service.description}
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            <div className="mb-16">
              <h2 className="text-2xl font-bold mb-8">Service Gallery</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {service.gallery.map((image, index) => (
                  <div key={index} className="rounded-lg overflow-hidden shadow-lg">
                    <img 
                      src={image} 
                      alt={`${service.title} example ${index + 1}`}
                      className="w-full h-64 object-cover transition-transform duration-300 hover:scale-105"
                    />
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <h2 className="text-2xl font-bold mb-6">Service Features</h2>
                <ul className="space-y-4">
                  {service.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-gray-700">
                      <Check className="w-5 h-5 text-primary-600 mr-3" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <h2 className="text-2xl font-bold mt-12 mb-6">Our Process</h2>
                <div className="space-y-4">
                  {service.process.map((step, index) => (
                    <div key={index} className="flex items-start">
                      <div className="w-8 h-8 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center flex-shrink-0 mt-1">
                        {index + 1}
                      </div>
                      <p className="ml-4 text-gray-700">{step}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="text-2xl font-bold mb-6">Pricing</h2>
                <div className="bg-white rounded-lg shadow-lg overflow-hidden">
                  <div className="divide-y">
                    {service.pricing.map((item, index) => (
                      <div key={index} className="p-4 flex justify-between items-center">
                        <span className="text-gray-700">{item.name}</span>
                        <span className="font-bold">${item.price}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <h2 className="text-2xl font-bold mt-12 mb-6">Frequently Asked Questions</h2>
                <div className="space-y-6">
                  {service.faq.map((item, index) => (
                    <div key={index}>
                      <h3 className="font-bold text-gray-900 mb-2">{item.question}</h3>
                      <p className="text-gray-700">{item.answer}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-lg p-6 sticky top-6">
              <h2 className="text-2xl font-bold mb-6">Service Options</h2>
              
              {loading ? (
                <div className="flex justify-center py-8">
                  <Loader className="w-8 h-8 animate-spin text-primary-600" />
                </div>
              ) : products.length === 0 ? (
                <p className="text-gray-600">No service options available</p>
              ) : (
                <>
                  {products.length > 1 && (
                    <div className="mb-6">
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Select Package
                      </label>
                      <select
                        value={selectedProduct?.id || ''}
                        onChange={(e) => {
                          const product = products.find(p => p.id === e.target.value);
                          setSelectedProduct(product || null);
                        }}
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                      >
                        {products.map(product => (
                          <option key={product.id} value={product.id}>
                            {product.name} - ${product.base_price.toFixed(2)}
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  {selectedProduct && (
                    <ServiceProductForm
                      product={selectedProduct}
                      onSubmit={handleProductSubmit}
                    />
                  )}
                </>
              )}
            </div>
          </div>
        </div>

        <div className="mt-16">
          <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {service.faq.map((item, index) => (
              <div key={index}>
                <h3 className="font-bold text-gray-900 mb-2">{item.question}</h3>
                <p className="text-gray-700">{item.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default ServiceDetails;