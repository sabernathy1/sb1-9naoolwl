import React from 'react';
import { Helmet } from 'react-helmet-async';
import { 
  Printer, 
  PenTool, 
  ShoppingCart, 
  Palette, 
  Clock,
  Check,
  ArrowRight,
  Info
} from 'lucide-react';
import { Link } from 'react-router-dom';

const Services = () => {
  const services = [
    {
      id: 'press-only',
      title: 'Bring Your Vision to Life—Pressed Perfectly!',
      icon: <Printer className="w-16 h-16 text-primary-600" />,
      image: 'https://images.unsplash.com/photo-1622557850710-d08a111d3476?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      description: "Got a design and an item you want it placed on, but don't have the tools to do it yourself? That's where we come in!",
      features: [
        'On-Site Service: We come to you',
        'Quick Turnaround Service',
        'Professional Equipment',
        'Expert Application'
      ],
      note: 'Pricing includes travel expense fee for your convenience',
      cta: 'Start Now'
    },
    {
      id: 'design-shop',
      title: 'Design, Shop, Create—All in One Place',
      icon: <PenTool className="w-16 h-16 text-primary-600" />,
      image: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      description: "Unleash your creativity with our design and shop experience! Share your vision, explore our collection, and we'll handle the rest.",
      features: [
        'Professional Design Service',
        'Premium Blank Selection',
        'Quality Printing',
        'Expert Pressing'
      ],
      tagline: 'Your ideas. Our craftsmanship. Perfectly personalized.',
      cta: 'Get Started'
    },
    {
      id: 'print-press',
      title: 'Your Design, Perfectly Pressed',
      icon: <ShoppingCart className="w-16 h-16 text-primary-600" />,
      image: 'https://images.unsplash.com/photo-1618004912476-29818d81ae2e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      description: 'Got a ready-to-print design and the perfect canvas? Let us handle the rest with precision and care.',
      features: [
        'Next-Day Service Available',
        'Same-Day Options',
        'Professional Quality',
        'Multiple Item Orders'
      ],
      tagline: 'Fast. Reliable. Hassle-Free.',
      cta: 'Submit Your Design'
    },
    {
      id: 'design-press',
      title: 'Your Canvas, Your Vision, Our Expertise',
      icon: <Palette className="w-16 h-16 text-primary-600" />,
      image: 'https://images.unsplash.com/photo-1621600411688-4be93cd68504?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      description: "Bring us your blank canvas and let's create something extraordinary together!",
      features: [
        'Collaborative Design Process',
        'Expert Design Assistance',
        'Professional Printing',
        'Quality Pressing'
      ],
      note: 'Design assistance level may affect final cost',
      cta: 'Start Your Custom Order'
    },
    {
      id: 'print-shop',
      title: 'Print Ready, Shop Smart',
      icon: <Clock className="w-16 h-16 text-primary-600" />,
      image: 'https://images.unsplash.com/photo-1513346940221-6f673d962e97?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      description: 'Browse our premium blanks and let us bring your ready-to-print designs to life with professional quality printing.',
      features: [
        'Premium Blank Selection',
        'Next-Day Service',
        'Bulk Order Options',
        'Quality Guaranteed'
      ],
      tagline: 'Quality materials. Professional printing. Perfect results.',
      cta: 'Shop Blanks'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Our Services - Perfectly Personalized</title>
        <meta name="description" content="Explore our range of customization services from design to printing and pressing." />
      </Helmet>

      <div className="bg-primary-900 text-white py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold text-center mb-4">Our Services</h1>
          <p className="text-xl text-primary-100 text-center max-w-2xl mx-auto">
            From design to delivery, we offer comprehensive customization services to bring your vision to life.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div 
              key={service.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                  <div className="text-white">
                    <div className="flex items-center gap-2 mb-2">
                      {service.icon}
                      <h3 className="text-xl font-bold">{service.title}</h3>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="p-6">
                <p className="text-gray-600 mb-6">{service.description}</p>
                
                <ul className="space-y-3 mb-6">
                  {service.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-gray-700">
                      <Check className="w-5 h-5 text-primary-600 mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>

                {service.tagline && (
                  <p className="text-primary-600 font-medium mb-4 italic">
                    "{service.tagline}"
                  </p>
                )}

                {service.note && (
                  <div className="flex items-start gap-2 text-sm text-gray-600 mb-6 bg-gray-50 p-3 rounded-lg">
                    <Info className="w-5 h-5 text-primary-600 flex-shrink-0 mt-0.5" />
                    <p>{service.note}</p>
                  </div>
                )}

                <Link
                  to={`/services/${service.id}`}
                  className="w-full bg-primary-600 text-white py-3 px-6 rounded-lg hover:bg-primary-700 transition duration-300 flex items-center justify-center gap-2"
                >
                  {service.cta}
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Services;