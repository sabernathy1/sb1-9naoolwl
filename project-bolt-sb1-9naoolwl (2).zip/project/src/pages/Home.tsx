import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { 
  ShoppingBag, 
  Palette, 
  Star, 
  Upload, 
  Settings, 
  Truck, 
  Heart, 
  ArrowRight,
  Printer,
  PenTool,
  ShoppingCart,
  Clock,
  Info,
  Check,
  Tag
} from 'lucide-react';

const Home = () => {
  const reviews = [
    {
      name: "Sarah M.",
      rating: 5,
      text: "Love my custom t-shirt! The quality is amazing and the design came out perfect.",
      image: "https://images.unsplash.com/photo-1554412933-514a83d2f3c8?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80"
    },
    {
      name: "Mike R.",
      rating: 5,
      text: "The customization process was so easy. Will definitely order again!",
      image: "https://images.unsplash.com/photo-1517841905240-472988babdf9?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80"
    },
    {
      name: "Emily L.",
      rating: 5,
      text: "Created matching shirts for our family reunion. Everyone loved them!",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80"
    }
  ];

  const steps = [
    {
      icon: <Upload className="w-12 h-12 text-primary-600" />,
      title: "Upload Your Design",
      description: "Upload your artwork or use our design tools to create something unique."
    },
    {
      icon: <Settings className="w-12 h-12 text-primary-600" />,
      title: "Customize",
      description: "Choose your product, size, color, and placement of your design."
    },
    {
      icon: <Truck className="w-12 h-12 text-primary-600" />,
      title: "Receive",
      description: "We'll carefully create your custom item and deliver it to your door."
    }
  ];

  const featuredProducts = [
    {
      id: 1,
      name: "Custom T-Shirt",
      price: 29.99,
      image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 2,
      name: "Custom Hoodie",
      price: 49.99,
      image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    },
    {
      id: 3,
      name: "Custom Cap",
      price: 24.99,
      image: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
    }
  ];

  const services = [
    {
      id: 'press-only',
      title: 'Bring Your Vision to Life—Pressed Perfectly!',
      icon: <Printer className="w-16 h-16 text-primary-600" />,
      description: "Got a design and an item you want it placed on, but don't have the tools to do it yourself? That's where we come in!",
      image: 'https://images.unsplash.com/photo-1622557850710-d08a111d3476?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      features: [
        'On-Site Service',
        'Quick Turnaround',
        'Professional Equipment'
      ]
    },
    {
      id: 'design-shop',
      title: 'Design, Shop, Create',
      icon: <PenTool className="w-16 h-16 text-primary-600" />,
      description: "Unleash your creativity with our design and shop experience! Share your vision, explore our collection, and we'll handle the rest.",
      image: 'https://images.unsplash.com/photo-1558655146-9f40138edfeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      features: [
        'Professional Design',
        'Premium Materials',
        'Expert Printing'
      ]
    },
    {
      id: 'print-press',
      title: 'Your Design, Perfectly Pressed',
      icon: <ShoppingCart className="w-16 h-16 text-primary-600" />,
      description: 'Got a ready-to-print design and the perfect canvas? Let us handle the rest with precision and care.',
      image: 'https://images.unsplash.com/photo-1618004912476-29818d81ae2e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
      features: [
        'Next-Day Service',
        'Multiple Items',
        'Quality Guaranteed'
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>Perfectly Personalized - Custom Apparel & Design</title>
        <meta name="description" content="Create your own custom designed t-shirts and apparel with Perfectly Personalized. Express yourself with unique, high-quality personalized clothing." />
      </Helmet>

      {/* Promotions Banner */}
      <section className="bg-primary-50 border-b border-primary-100">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-center gap-6 text-center md:text-left">
            <div className="flex items-center gap-3">
              <Tag className="w-6 h-6 text-primary-600" />
              <p className="text-primary-800 font-medium">
                Save 20% on bulk orders of 5+ apparel items!
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Truck className="w-6 h-6 text-primary-600" />
              <p className="text-primary-800 font-medium">
                FREE shipping on orders over $50!
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary-900 to-primary-800 text-white">
        <div className="absolute inset-0 bg-black/30 mix-blend-multiply" />
        <div className="relative container mx-auto px-4 py-24 lg:py-32">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 font-display">
              You think it,<br />we make it.
            </h1>
            <p className="text-xl mb-8 text-primary-100">
              Turn your ideas into custom-made reality with our premium personalized products
            </p>
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 bg-white text-primary-900 px-8 py-3 rounded-full font-semibold hover:bg-primary-100 transition duration-300"
            >
              Start Creating
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6">
              <ShoppingBag className="w-12 h-12 text-primary-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Quality Products</h3>
              <p className="text-gray-600">Premium materials for lasting comfort and style</p>
            </div>
            <div className="text-center p-6">
              <Palette className="w-12 h-12 text-primary-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Custom Design</h3>
              <p className="text-gray-600">Create your perfect design with our easy-to-use tools</p>
            </div>
            <div className="text-center p-6">
              <Heart className="w-12 h-12 text-primary-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Made with Love</h3>
              <p className="text-gray-600">Each item is crafted with attention to detail</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Our Services</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Choose the perfect service for your needs, from full-service design and printing to simple pressing
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => (
              <Link 
                key={service.id}
                to={`/services/${service.id}`}
                className="group bg-white rounded-xl shadow-lg overflow-hidden transform transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
              >
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                    <div className="text-white">
                      <div className="flex items-center gap-2 mb-2">
                        {service.icon}
                        <h3 className="text-xl font-bold">{service.title}</h3>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <p className="text-gray-600 mb-6">{service.description}</p>
                  
                  <ul className="space-y-3 mb-6">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-gray-700">
                        <Check className="w-5 h-5 text-primary-600 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <div className="flex items-center justify-end text-primary-600 group-hover:text-primary-700">
                    <span className="font-medium">Learn More</span>
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link
              to="/services"
              className="inline-flex items-center gap-2 text-primary-600 hover:text-primary-700 font-medium"
            >
              View All Services
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Featured Products</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredProducts.map((product) => (
              <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{product.name}</h3>
                  <div className="flex justify-between items-center">
                    <span className="text-primary-600 font-bold">${product.price}</span>
                    <Link
                      to={`/product/${product.id}`}
                      className="bg-primary-600 text-white px-4 py-2 rounded hover:bg-primary-700 transition duration-300"
                    >
                      Customize
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="text-center p-6">
                <div className="mb-4">{step.icon}</div>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Customer Reviews */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">What Our Customers Say</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {reviews.map((review, index) => (
              <div key={index} className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center mb-4">
                  <img
                    src={review.image}
                    alt={review.name}
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h3 className="font-semibold">{review.name}</h3>
                    <div className="flex text-yellow-400">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600">{review.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-primary-900 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Create Something Amazing?</h2>
          <p className="text-primary-100 mb-8 max-w-2xl mx-auto">
            Join thousands of satisfied customers who have brought their creative ideas to life
          </p>
          <Link
            to="/shop"
            className="inline-flex items-center gap-2 bg-white text-primary-900 px-8 py-3 rounded-full font-semibold hover:bg-primary-100 transition duration-300"
          >
            Start Your Custom Design
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </>
  );
};

export default Home;