import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useLocation, Link } from 'react-router-dom';
import { CheckCircle, Package, ArrowRight } from 'lucide-react';

const OrderConfirmation = () => {
  const location = useLocation();
  const { orderDetails } = location.state || {};

  if (!orderDetails) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">No order details found.</p>
          <Link to="/" className="text-primary-600 hover:text-primary-700 mt-4 inline-block">
            Return to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Order Confirmation - Perfectly Personalized</title>
        <meta name="description" content="Thank you for your order!" />
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-md p-8">
            <div className="text-center mb-8">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Thank You for Your Order!</h1>
              <p className="text-gray-600">
                Order #{orderDetails.orderId}
              </p>
            </div>

            <div className="border-t border-b py-6 my-6">
              <h2 className="text-xl font-semibold mb-4">Order Details</h2>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-gray-900">Shipping Address</h3>
                  <p className="text-gray-600">
                    {orderDetails.customerInfo.firstName} {orderDetails.customerInfo.lastName}<br />
                    {orderDetails.customerInfo.address}<br />
                    {orderDetails.customerInfo.city}, {orderDetails.customerInfo.state} {orderDetails.customerInfo.zipCode}<br />
                    {orderDetails.customerInfo.country}
                  </p>
                </div>

                <div>
                  <h3 className="font-medium text-gray-900">Contact Information</h3>
                  <p className="text-gray-600">{orderDetails.customerInfo.email}</p>
                </div>
              </div>
            </div>

            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
              {orderDetails.items.map((item, index) => (
                <div key={index} className="flex items-center justify-between py-4 border-b last:border-b-0">
                  <div className="flex items-center gap-4">
                    {item.product && (
                      <img
                        src={item.product.image_url}
                        alt={item.product.name}
                        className="w-16 h-16 object-cover rounded"
                      />
                    )}
                    <div>
                      <p className="font-medium">{item.product?.name || 'Product'}</p>
                      <p className="text-sm text-gray-600">
                        Quantity: {item.quantity}
                        {item.customization?.size && ` • Size: ${item.customization.size}`}
                      </p>
                    </div>
                  </div>
                  <span className="font-medium">${((item.product?.price || 0) * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              <div className="border-t mt-4 pt-4">
                <div className="flex justify-between font-semibold">
                  <span>Total</span>
                  <span>${orderDetails.total.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg mb-8">
              <div className="flex items-center gap-2 text-gray-600">
                <Package className="w-5 h-5" />
                <span>You will receive a shipping confirmation email when your order ships.</span>
              </div>
            </div>

            <div className="text-center">
              <Link
                to="/shop"
                className="inline-flex items-center gap-2 bg-primary-600 text-white px-6 py-3 rounded-lg hover:bg-primary-700 transition duration-300"
              >
                <span>Continue Shopping</span>
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default OrderConfirmation;