import React, { useEffect, useState } from 'react';  
import { Helmet } from 'react-helmet-async';  
import { useCartStore } from '../store/cartStore';  
import { Trash2, ArrowRight, Info, Tag } from 'lucide-react';  
import { Link, useNavigate } from 'react-router-dom';  
import { supabase } from '../lib/supabase';  
import type { Product, ProductVariant } from '../types';  
import toast from 'react-hot-toast';

const Cart = () => {  
  const { items, removeItem, updateQuantity } = useCartStore();  
  const navigate = useNavigate();  
  const [products, setProducts] = useState<Record<string, Product>>({});
  const [variants, setVariants] = useState<Record<string, ProductVariant>>({});
  const [loading, setLoading] = useState(true);  

  useEffect(() => {  
    const fetchProductsAndVariants = async () => {  
      try {  
        const productIds = items.map(item => item.product_id);
        const variantIds = items.map(item => item.variant_id).filter(Boolean);

        if (productIds.length === 0) {  
          setLoading(false);  
          return;  
        }  

        const { data: productsData, error: productsError } = await supabase  
          .from('products')  
          .select('*')  
          .in('id', productIds);  

        if (productsError) throw productsError;  

        const productsMap = (productsData || []).reduce((acc, product) => {  
          acc[product.id] = product;  
          return acc;  
        }, {} as Record<string, Product>);  

        setProducts(productsMap);

        if (variantIds.length > 0) {
          const { data: variantsData, error: variantsError } = await supabase
            .from('product_variants')
            .select('*')
            .in('id', variantIds);

          if (variantsError) throw variantsError;

          const variantsMap = (variantsData || []).reduce((acc, variant) => {
            acc[variant.id] = variant;
            return acc;
          }, {} as Record<string, ProductVariant>);

          setVariants(variantsMap);
        }
      } catch (error) {  
        console.error('Error fetching products:', error);
        toast.error('Failed to load cart items');
      } finally {  
        setLoading(false);  
      }  
    };  

    fetchProductsAndVariants();
  }, [items]);  

  const calculateItemTotal = (item) => {
    const variant = item.variant_id ? variants[item.variant_id] : null;
    const product = products[item.product_id];
    const basePrice = variant?.price || product?.price || 0;
    const adjustment = item.price_adjustment || 0;
    return (basePrice + adjustment) * item.quantity;
  };

  const calculateSubtotal = () => {
    return items.reduce((total, item) => total + calculateItemTotal(item), 0);
  };

  const getApparelCount = () => {
    return items.reduce((count, item) => {
      const product = products[item.product_id];
      if (product?.category === 'T-Shirts' || product?.category === 'Hoodies') {
        return count + item.quantity;
      }
      return count;
    }, 0);
  };

  const calculateDiscount = () => {
    const apparelCount = getApparelCount();
    if (apparelCount >= 5) {
      return calculateSubtotal() * 0.2; // 20% discount
    }
    return 0;
  };

  const calculateShipping = (subtotalAfterDiscount: number) => {
    return subtotalAfterDiscount >= 50 ? 0 : 5.99;
  };

  const calculateTotal = () => {
    const subtotal = calculateSubtotal();
    const discount = calculateDiscount();
    const subtotalAfterDiscount = subtotal - discount;
    const shipping = calculateShipping(subtotalAfterDiscount);
    return subtotalAfterDiscount + shipping;
  };

  const renderDesignPreview = (customization) => {
    if (!customization?.designs) return null;

    const designEntries = Object.entries(customization.designs);
    if (designEntries.length === 0) return null;

    return (
      <div className="design-preview mt-2">
        {designEntries.map(([placement, designUrl]) => (
          <div key={placement} className="flex items-center gap-2 text-sm text-gray-600">
            <span className="capitalize">{placement.replace('-', ' ')}:</span>
            <img 
              src={designUrl as string} 
              alt={`Design on ${placement}`} 
              className="w-16 h-16 object-contain border rounded"
            />
          </div>
        ))}
      </div>
    );
  };

  if (loading) {  
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );  
  }  

  const subtotal = calculateSubtotal();
  const discount = calculateDiscount();
  const subtotalAfterDiscount = subtotal - discount;
  const shipping = calculateShipping(subtotalAfterDiscount);
  const apparelCount = getApparelCount();

  return (  
    <div className="container mx-auto px-4 py-8">  
      <Helmet>  
        <title>Your Cart - Personalized Perfection</title>
        <meta name="description" content="Review and manage your cart items" />
      </Helmet>  
      <h2 className="text-2xl font-bold mb-4">Your Cart</h2>  
      {items.length === 0 ? (  
        <div className="text-center py-8">
          <p className="text-gray-600 mb-4">Your cart is empty.</p>
          <Link
            to="/shop"
            className="inline-flex items-center gap-2 bg-primary-600 text-white px-6 py-3 rounded-lg hover:bg-primary-700 transition duration-300"
          >
            Continue Shopping
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      ) : (  
        <div>  
          {apparelCount >= 5 && (
            <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
              <Tag className="w-5 h-5 text-green-600" />
              <p className="text-green-800">
                Bulk order discount of 20% applied to your cart!
              </p>
            </div>
          )}
          {subtotalAfterDiscount >= 50 && (
            <div className="mb-6 bg-primary-50 border border-primary-200 rounded-lg p-4 flex items-center gap-3">
              <Info className="w-5 h-5 text-primary-600" />
              <p className="text-primary-800">
                Free shipping applied to your order!
              </p>
            </div>
          )}
          {items.map(item => {  
            const product = products[item.product_id];
            const variant = item.variant_id ? variants[item.variant_id] : null;
            const basePrice = variant?.price || product?.price || 0;
            const hasUpcharge = item.price_adjustment && item.price_adjustment > 0;

            return (  
              <div key={item.id} className="flex justify-between items-start mb-4 p-4 border rounded-lg">  
                <div className="flex-1">  
                  <h3 className="text-lg font-semibold">{product?.name}</h3>
                  {variant && (
                    <div className="text-sm text-gray-600 mt-1 space-y-1">
                      {variant.attributes.color && (
                        <p>Color: {variant.attributes.color}</p>
                      )}
                      {variant.attributes.size && (
                        <p>Size: {variant.attributes.size}</p>
                      )}
                    </div>
                  )}
                  {renderDesignPreview(item.customization)}
                  {hasUpcharge && (
                    <div className="flex items-center gap-2 text-sm text-primary-600 mt-2">
                      <Info className="w-4 h-4" />
                      <span>Additional design charge: ${item.price_adjustment.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="mt-2">
                    <label className="text-sm text-gray-600 mr-2">Quantity:</label>
                    <input  
                      type="number"  
                      value={item.quantity}  
                      onChange={(e) => updateQuantity(item.id, Number(e.target.value))}  
                      min="1"
                      max={variant?.stock || 999}
                      className="border rounded p-1 w-16"  
                    />  
                  </div>
                </div>  
                <div className="flex flex-col items-end">  
                  <div className="text-right">
                    <span className="text-xl font-bold">
                      ${calculateItemTotal(item).toFixed(2)}
                    </span>
                    {hasUpcharge && (
                      <p className="text-sm text-gray-600">
                        Base: ${(basePrice * item.quantity).toFixed(2)}
                      </p>
                    )}
                  </div>
                  <button 
                    onClick={() => removeItem(item.id)} 
                    className="mt-2 text-red-600 hover:text-red-700 transition-colors"
                  >  
                    <Trash2 className="w-5 h-5" />  
                  </button>  
                </div>  
              </div>  
            );  
          })}  
          <div className="mt-8 border-t pt-4 space-y-4">
            <div className="flex justify-between text-gray-600">
              <span>Subtotal:</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-green-600">
                <span>Bulk Order Discount (20%):</span>
                <span>-${discount.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-gray-600">
              <span>Shipping:</span>
              <span>{shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}</span>
            </div>
            <div className="flex justify-between text-xl font-bold border-t pt-4">
              <span>Total:</span>
              <span>${calculateTotal().toFixed(2)}</span>
            </div>
          </div>
          <button  
            onClick={() => navigate('/checkout')}  
            className="mt-6 w-full bg-primary-600 text-white px-6 py-3 rounded-lg hover:bg-primary-700 transition duration-300 flex items-center justify-center gap-2"  
          >  
            <span>Proceed to Checkout</span>
            <ArrowRight className="w-5 h-5" />  
          </button>  
        </div>  
      )}  
    </div>  
  );  
};  

export default Cart;