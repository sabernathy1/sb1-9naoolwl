import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { supabase, checkSupabaseConnection } from '../lib/supabase';
import type { Product, ProductVariant } from '../types';
import { Filter, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';

interface ProductWithVariants extends Product {
  variants: ProductVariant[];
}

const Shop = () => {
  const [products, setProducts] = useState<ProductWithVariants[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [error, setError] = useState<string | null>(null);
  const [connectionError, setConnectionError] = useState(false);

  useEffect(() => {
    const initializeConnection = async () => {
      const isConnected = await checkSupabaseConnection();
      if (!isConnected) {
        setConnectionError(true);
        setLoading(false);
        return;
      }
      fetchProducts();
    };

    const fetchProducts = async () => {
      try {
        console.log('Fetching products for category:', selectedCategory);
        
        // First, let's check if we can get any products at all
        const { data: allProducts, error: countError } = await supabase
          .from('products')
          .select('*');
          
        console.log('All products check:', allProducts);
        
        if (countError) {
          console.error('Error checking products:', countError);
          throw countError;
        }

        // Now fetch products with variants
        let query = supabase
          .from('products')
          .select(`
            *,
            variants:product_variants (
              id,
              name,
              sku,
              price,
              stock,
              attributes,
              image_url
            )
          `);
        
        if (selectedCategory !== 'all') {
          query = query.eq('category', selectedCategory);
        }

        const { data, error: supabaseError } = await query;

        if (supabaseError) {
          console.error('Supabase error:', supabaseError);
          throw supabaseError;
        }

        console.log('Fetched products with variants:', data);
        
        if (!data || data.length === 0) {
          console.log('No products found');
        }

        setProducts(data || []);
        setError(null);
      } catch (err) {
        console.error('Error fetching products:', err);
        setError('Failed to load products. Please try again later.');
        toast.error('Failed to load products');
      } finally {
        setLoading(false);
      }
    };

    initializeConnection();
  }, [selectedCategory]);

  if (connectionError) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-red-600" />
          <div>
            <h3 className="font-medium text-red-800">Connection Error</h3>
            <p className="text-red-600">
              Unable to connect to the server. Please try again later.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const categories = ['all', 'T-Shirts', 'Hoodies', 'Accessories'];

  const getUniqueColors = (variants: ProductVariant[]) => {
    const colors = new Set(variants.map(v => v.attributes.color).filter(Boolean));
    return Array.from(colors);
  };

  return (
    <>
      <Helmet>
        <title>Shop - Perfectly Personalized</title>
        <meta name="description" content="Browse our collection of customizable apparel and accessories." />
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Shop Our Collection</h1>
          <div className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-gray-600" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-1.5 focus:ring-primary-500 focus:border-primary-500"
            >
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category === 'all' ? 'All Categories' : category}
                </option>
              ))}
            </select>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
          </div>
        ) : error ? (
          <div className="text-center text-red-600 py-8">{error}</div>
        ) : products.length === 0 ? (
          <div className="text-center text-gray-600 py-8">
            <p>No products found in this category.</p>
            <p className="text-sm mt-2">Please check the database connection or try refreshing the page.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map((product) => {
              const colors = getUniqueColors(product.variants || []);
              const defaultVariant = product.variants?.[0];

              return (
                <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                  <div className="relative aspect-square bg-gray-50">
                    <img
                      src={defaultVariant?.image_url || product.image_url}
                      alt={product.name}
                      className="w-full h-full object-contain"
                      loading="lazy"
                      onError={(e) => {
                        const img = e.target as HTMLImageElement;
                        img.src = 'https://via.placeholder.com/400?text=Product+Image+Not+Found';
                      }}
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">{product.name}</h3>
                    <p className="text-gray-600 mb-4 line-clamp-2">{product.description}</p>
                    
                    {colors.length > 0 && (
                      <div className="mb-4">
                        <p className="text-sm text-gray-600 mb-2">Available Colors:</p>
                        <div className="flex flex-wrap gap-2">
                          {colors.map((color) => (
                            <div
                              key={color}
                              className="w-6 h-6 rounded-full border border-gray-300"
                              style={{ backgroundColor: color.toLowerCase() }}
                              title={color}
                            />
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="flex justify-between items-center">
                      <span className="text-primary-600 font-bold">${product.price.toFixed(2)}</span>
                      <a
                        href={`/product/${product.id}`}
                        className="bg-primary-600 text-white px-4 py-2 rounded hover:bg-primary-700 transition duration-300"
                      >
                        Customize
                      </a>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
};

export default Shop;