import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { supabase } from '../lib/supabase';
import { Filter, ShoppingBag } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

interface GalleryImage {
  id: string;
  url: string;
  watermarked_url: string;
  category: string;
}

const Gallery = () => {
  const [designs, setDesigns] = useState<GalleryImage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDesigns = async () => {
      try {
        let query = supabase.from('gallery_images').select('*');
        
        if (selectedCategory !== 'all') {
          query = query.eq('category', selectedCategory);
        }

        const { data, error: supabaseError } = await query;

        if (supabaseError) throw supabaseError;
        setDesigns(data || []);
        setError(null);
      } catch (err) {
        console.error('Error fetching designs:', err);
        setError('Failed to load designs. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchDesigns();
  }, [selectedCategory]);

  const categories = ['all', 'Abstract', 'Nature', 'Typography', 'Animals', 'Sports', 'Music'];

  const handleUseDesign = (designUrl: string) => {
    localStorage.setItem('selectedDesign', designUrl);
    navigate('/shop');
    toast.success('Design selected! Choose a product to customize.');
  };

  return (
    <>
      <Helmet>
        <title>Design Gallery - Perfectly Personalized</title>
        <meta name="description" content="Browse our gallery of custom designs and get inspired." />
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Design Gallery</h1>
            <p className="text-gray-600">Browse our collection of designs or use them on your custom products</p>
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-gray-600" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="border border-gray-300 rounded-md px-3 py-1.5 focus:ring-primary-500 focus:border-primary-500"
            >
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category === 'all' ? 'All Categories' : category}
                </option>
              ))}
            </select>
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
          </div>
        ) : error ? (
          <div className="text-center text-red-600 py-8">{error}</div>
        ) : designs.length === 0 ? (
          <div className="text-center text-gray-600 py-8">
            No designs found in this category.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {designs.map((design) => (
              <div 
                key={design.id} 
                className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
              >
                <div className="relative aspect-square group">
                  <div className="absolute inset-0 bg-gray-100">
                    <img
                      src={design.watermarked_url}
                      alt={`Design in ${design.category} category`}
                      className="w-full h-full object-contain"
                      loading="lazy"
                      onError={(e) => {
                        const img = e.target as HTMLImageElement;
                        img.src = 'https://via.placeholder.com/400?text=Image+Not+Found';
                      }}
                    />
                  </div>
                  <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <button
                      onClick={() => handleUseDesign(design.url)}
                      className="bg-white text-primary-600 px-4 py-2 rounded-full flex items-center space-x-2 hover:bg-primary-50 transition duration-300"
                    >
                      <ShoppingBag className="w-5 h-5" />
                      <span>Use This Design</span>
                    </button>
                  </div>
                </div>
                <div className="p-4">
                  <span className="inline-block bg-primary-100 text-primary-800 text-sm px-3 py-1 rounded-full">
                    {design.category}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
};

export default Gallery;