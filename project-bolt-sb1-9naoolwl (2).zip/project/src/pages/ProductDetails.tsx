import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { supabase } from '../lib/supabase';
import { ShoppingBag, AlertCircle, Info, ChevronLeft, ChevronRight } from 'lucide-react';
import toast from 'react-hot-toast';
import type { Product, ProductVariant } from '../types';
import { useCartStore } from '../store/cartStore';
import ProductCustomizer from '../components/ProductCustomizer';

type DesignPlacement = 'front' | 'back' | 'left-sleeve' | 'right-sleeve';

const MULTI_DESIGN_UPCHARGE = 5.00;

const ProductDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedVariant, setSelectedVariant] = useState<ProductVariant | null>(null);
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [customDesigns, setCustomDesigns] = useState<Record<DesignPlacement, string | null>>({
    front: null,
    back: null,
    'left-sleeve': null,
    'right-sleeve': null
  });
  const [selectedPlacements, setSelectedPlacements] = useState<string[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const addItem = useCartStore((state) => state.addItem);

  // Calculate number of designs and upcharge
  const designCount = Object.values(customDesigns).filter(Boolean).length;
  const upchargeAmount = designCount > 1 ? MULTI_DESIGN_UPCHARGE : 0;

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const { data: productData, error: productError } = await supabase
          .from('products')
          .select(`
            *,
            preview_images,
            image_url_front,
            image_url_back,
            image_url_left_sleeve,
            image_url_right_sleeve,
            available_placements
          `)
          .eq('id', id)
          .single();

        if (productError) throw productError;

        const { data: variantsData, error: variantsError } = await supabase
          .from('product_variants')
          .select('*')
          .eq('product_id', id);

        if (variantsError) throw variantsError;

        const productWithVariants = {
          ...productData,
          variants: variantsData
        };

        setProduct(productWithVariants);

        if (variantsData.length > 0) {
          const colors = [...new Set(variantsData.map(v => v.attributes.color))];
          const sizes = [...new Set(variantsData.map(v => v.attributes.size))].filter(Boolean);
          
          if (colors.length > 0) setSelectedColor(colors[0]);
          if (sizes.length > 0) setSelectedSize(sizes[0]);
        }
      } catch (error) {
        console.error('Error fetching product:', error);
        toast.error('Failed to load product details');
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [id]);

  useEffect(() => {
    if (product?.variants) {
      const variant = product.variants.find(v => 
        v.attributes.color === selectedColor && 
        (!v.attributes.size || v.attributes.size === selectedSize)
      );
      setSelectedVariant(variant || null);
    }
  }, [selectedColor, selectedSize, product]);

  const handleAddToCart = () => {
    if (!product) return;

    if (!selectedVariant) {
      toast.error('Please select all required options');
      return;
    }

    const designs = Object.entries(customDesigns).reduce((acc, [key, value]) => {
      if (value) {
        acc[key as DesignPlacement] = value;
      }
      return acc;
    }, {} as Record<string, string>);

    const designCount = Object.keys(designs).length;
    const upcharge = designCount > 1 ? (designCount - 1) * MULTI_DESIGN_UPCHARGE : 0;

    const cartItem = {
      id: crypto.randomUUID(),
      product_id: product.id,
      variant_id: selectedVariant.id,
      quantity: 1,
      customization: {
        designs,
        color: selectedColor,
        size: selectedSize,
      },
      price_adjustment: upcharge
    };

    addItem(cartItem);
    
    toast.success(
      designCount > 1 
        ? `Added to cart with ${designCount - 1} additional design${designCount > 2 ? 's' : ''}!`
        : 'Added to cart!'
    );
    navigate('/cart');
  };

  const getAvailableColors = () => {
    if (!product?.variants) return [];
    return [...new Set(product.variants.map(v => v.attributes.color))];
  };

  const getAvailableSizes = () => {
    if (!product?.variants) return [];
    return [...new Set(product.variants
      .filter(v => v.attributes.size)
      .map(v => v.attributes.size)
    )].sort((a, b) => {
      const sizeOrder = { 'XS': 0, 'S': 1, 'M': 2, 'L': 3, 'XL': 4, 'XXL': 5 };
      return sizeOrder[a] - sizeOrder[b];
    });
  };

  const handlePrevImage = () => {
    setCurrentImageIndex(prev => 
      prev === 0 ? (product?.preview_images?.length || 1) - 1 : prev - 1
    );
  };

  const handleNextImage = () => {
    setCurrentImageIndex(prev => 
      prev === (product?.preview_images?.length || 1) - 1 ? 0 : prev + 1
    );
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-bold text-red-600">Product not found</h1>
      </div>
    );
  }

  const productViews = {
    front: product.image_url_front || product.image_url,
    back: product.image_url_back || null,
    'left-sleeve': product.image_url_left_sleeve || null,
    'right-sleeve': product.image_url_right_sleeve || null
  };

  const colors = getAvailableColors();
  const sizes = getAvailableSizes();
  const previewImages = product.preview_images || [product.image_url];

  return (
    <>
      <Helmet>
        <title>{`${product.name} - Personalized Perfection`}</title>
        <meta name="description" content={product.description} />
      </Helmet>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            {/* Show main product view when no placements are selected */}
            {selectedPlacements.length === 0 && (
              <div className="relative">
                <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                  <img
                    src={previewImages[currentImageIndex]}
                    alt={`${product.name} view ${currentImageIndex + 1}`}
                    className="w-full h-full object-cover"
                  />
                  {previewImages.length > 1 && (
                    <>
                      <button
                        onClick={handlePrevImage}
                        className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 p-2 rounded-full hover:bg-white transition-colors"
                      >
                        <ChevronLeft className="w-6 h-6" />
                      </button>
                      <button
                        onClick={handleNextImage}
                        className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 p-2 rounded-full hover:bg-white transition-colors"
                      >
                        <ChevronRight className="w-6 h-6" />
                      </button>
                      <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
                        {previewImages.map((_, index) => (
                          <button
                            key={index}
                            onClick={() => setCurrentImageIndex(index)}
                            className={`w-2 h-2 rounded-full transition-colors ${
                              index === currentImageIndex
                                ? 'bg-primary-600'
                                : 'bg-white/80 hover:bg-white'
                            }`}
                          />
                        ))}
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}

            <ProductCustomizer
              productViews={productViews}
              onDesignChange={setCustomDesigns}
              availablePlacements={product.available_placements}
              onPlacementsChange={setSelectedPlacements}
            />
          </div>

          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
              <p className="text-gray-600">{product.description}</p>
            </div>

            <div className="space-y-2">
              <div className="text-2xl font-bold text-primary-600">
                ${(selectedVariant?.price || product.price).toFixed(2)}
              </div>
              
              {designCount > 1 && (
                <div className="flex items-center gap-2 text-sm text-primary-600 bg-primary-50 p-2 rounded">
                  <Info className="w-4 h-4" />
                  <span>
                    Multi-design upcharge: ${MULTI_DESIGN_UPCHARGE.toFixed(2)} per additional design
                  </span>
                </div>
              )}
            </div>

            {colors.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Color
                </label>
                <div className="flex flex-wrap gap-2">
                  {colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`w-8 h-8 rounded-full border-2 ${
                        selectedColor === color
                          ? 'border-primary-600 ring-2 ring-primary-600 ring-offset-2'
                          : 'border-gray-300'
                      }`}
                      style={{ backgroundColor: color.toLowerCase() }}
                      title={color}
                    />
                  ))}
                </div>
              </div>
            )}

            {sizes.length > 0 && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Size
                </label>
                <div className="flex flex-wrap gap-2">
                  {sizes.map((size) => (
                    <button
                      key={size}
                      className={`px-4 py-2 rounded-md ${
                        selectedSize === size
                          ? 'bg-primary-600 text-white'
                          : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                      }`}
                      onClick={() => setSelectedSize(size)}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {selectedVariant && selectedVariant.stock <= 5 && (
              <div className="flex items-center gap-2 text-amber-600">
                <AlertCircle className="w-5 h-5" />
                <span className="text-sm">
                  Only {selectedVariant.stock} left in stock!
                </span>
              </div>
            )}

            <button
              onClick={handleAddToCart}
              disabled={!selectedVariant || selectedVariant.stock === 0}
              className="w-full bg-primary-600 text-white py-3 rounded-md hover:bg-primary-700 transition duration-300 flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ShoppingBag className="w-5 h-5" />
              <span>
                {!selectedVariant
                  ? 'Select options'
                  : selectedVariant.stock === 0
                  ? 'Out of stock'
                  : 'Add to Cart'}
              </span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProductDetails;