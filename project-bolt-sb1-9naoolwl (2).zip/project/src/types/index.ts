export interface User {
  id: string;
  email: string;
  full_name?: string;
  avatar_url?: string;
  created_at: string;
}

export interface ProductVariant {
  id: string;
  product_id: string;
  name: string;
  sku: string;
  price: number;
  stock: number;
  attributes: {
    size?: string;
    color?: string;
    [key: string]: any;
  };
  created_at: string;
  updated_at: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image_url: string;
  category: string;
  customizable: boolean;
  created_at: string;
  variants?: ProductVariant[];
}

export interface CartItem {
  id: string;
  product_id: string;
  variant_id?: string;
  quantity: number;
  price_adjustment?: number;
  customization?: {
    designs?: Record<string, string>;
    text?: string;
    color?: string;
    size?: string;
  };
}

export interface ServiceOption {
  label: string;
  value: string;
  price: number;
}

export interface ServiceOptionGroup {
  name: string;
  type: 'select';
  required: boolean;
  options: ServiceOption[];
}

export interface ServiceProduct {
  id: string;
  service_id: string;
  name: string;
  description: string;
  base_price: number;
  options: ServiceOptionGroup[];
  created_at: string;
  updated_at: string;
}

export interface ServiceProductSelection {
  product_id: string;
  options: Record<string, string>;
}