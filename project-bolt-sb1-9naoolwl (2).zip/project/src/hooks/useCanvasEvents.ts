import { useCallback } from 'react';
import { fabric } from 'fabric';

export const useCanvasEvents = () => {
  const setupCanvasEvents = useCallback((
    canvas: fabric.Canvas,
    handlers: {
      onSelect?: (object: fabric.Object | null) => void;
      onChange?: () => void;
    }
  ) => {
    canvas.on('selection:created', (e) => {
      handlers.onSelect?.(e.selected?.[0] || null);
    });

    canvas.on('selection:cleared', () => {
      handlers.onSelect?.(null);
    });

    canvas.on('object:modified', handlers.onChange);
    canvas.on('object:added', handlers.onChange);
    canvas.on('object:removed', handlers.onChange);

    return () => {
      canvas.off('selection:created');
      canvas.off('selection:cleared');
      canvas.off('object:modified');
      canvas.off('object:added');
      canvas.off('object:removed');
    };
  }, []);

  return { setupCanvasEvents };
};