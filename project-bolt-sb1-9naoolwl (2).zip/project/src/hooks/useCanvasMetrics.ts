import { useCallback, useRef } from 'react';

interface CanvasMetric {
  action: string;
  duration: number;
  timestamp: number;
}

export const useCanvasMetrics = () => {
  const metricsRef = useRef<CanvasMetric[]>([]);

  const reportMetric = useCallback((action: string, duration: number) => {
    const metric: CanvasMetric = {
      action,
      duration,
      timestamp: Date.now()
    };

    metricsRef.current.push(metric);

    // Log to console in development
    if (process.env.NODE_ENV === 'development') {
      console.log(`Canvas Metric - ${action}: ${duration}ms`);
    }

    // Could send to analytics service here
  }, []);

  const getMetrics = useCallback(() => {
    return metricsRef.current;
  }, []);

  return { reportMetric, getMetrics };
};