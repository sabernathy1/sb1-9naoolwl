import { useState, useCallback } from 'react';

interface LoadingStates {
  canvas: boolean;
  background: boolean;
  image: boolean;
}

export const useLoadingState = () => {
  const [loadingStates, setLoadingStates] = useState<LoadingStates>({
    canvas: false,
    background: false,
    image: false
  });

  const setLoading = useCallback((key: keyof LoadingStates, value: boolean) => {
    setLoadingStates(prev => ({ ...prev, [key]: value }));
  }, []);

  const isAnyLoading = Object.values(loadingStates).some(Boolean);

  return { loadingStates, setLoading, isAnyLoading };
};