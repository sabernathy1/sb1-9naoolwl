import { useCallback } from 'react';
import { fabric } from 'fabric';

export const useCanvasPersistence = () => {
  const persistCanvasState = useCallback((canvas: fabric.Canvas, placement: string) => {
    try {
      const state = canvas.toJSON();
      localStorage.setItem(`canvas_state_${placement}`, JSON.stringify(state));
    } catch (error) {
      console.error('Error persisting canvas state:', error);
    }
  }, []);

  const loadCanvasState = useCallback((canvas: fabric.Canvas, placement: string) => {
    try {
      const savedState = localStorage.getItem(`canvas_state_${placement}`);
      if (savedState) {
        canvas.loadFromJSON(JSON.parse(savedState), () => {
          canvas.renderAll();
        });
      }
    } catch (error) {
      console.error('Error loading canvas state:', error);
    }
  }, []);

  const clearCanvasState = useCallback((placement: string) => {
    localStorage.removeItem(`canvas_state_${placement}`);
  }, []);

  return { persistCanvasState, loadCanvasState, clearCanvasState };
};