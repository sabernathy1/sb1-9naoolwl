interface ImageLoadOptions {
  maxRetries?: number;
  retryDelay?: number;
  timeout?: number;
}

export const loadImageWithRetry = async (
  url: string,
  options: ImageLoadOptions = {}
): Promise<HTMLImageElement> => {
  const {
    maxRetries = 3,
    retryDelay = 1000,
    timeout = 10000
  } = options;

  const loadImage = (attempt: number): Promise<HTMLImageElement> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      let timeoutId: number;

      const cleanup = () => {
        img.onload = null;
        img.onerror = null;
        window.clearTimeout(timeoutId);
      };

      img.onload = () => {
        cleanup();
        resolve(img);
      };

      img.onerror = () => {
        cleanup();
        if (attempt < maxRetries) {
          setTimeout(() => {
            loadImage(attempt + 1)
              .then(resolve)
              .catch(reject);
          }, retryDelay * attempt); // Exponential backoff
        } else {
          reject(new Error(`Failed to load image after ${maxRetries} attempts`));
        }
      };

      timeoutId = window.setTimeout(() => {
        cleanup();
        reject(new Error('Image load timeout'));
      }, timeout);

      img.crossOrigin = 'anonymous';
      img.src = url;
    });
  };

  return loadImage(1);
};

export const optimizeImage = (img: HTMLImageElement): HTMLImageElement => {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    return img;
  }

  // Set maximum dimensions while maintaining aspect ratio
  const MAX_SIZE = 1024;
  let width = img.width;
  let height = img.height;

  if (width > height) {
    if (width > MAX_SIZE) {
      height = Math.round((height * MAX_SIZE) / width);
      width = MAX_SIZE;
    }
  } else {
    if (height > MAX_SIZE) {
      width = Math.round((width * MAX_SIZE) / height);
      height = MAX_SIZE;
    }
  }

  // Set canvas dimensions
  canvas.width = width;
  canvas.height = height;

  // Draw and optimize
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(img, 0, 0, width, height);

  // Create new optimized image
  const optimizedImg = new Image();
  optimizedImg.src = canvas.toDataURL('image/png', 0.9);
  optimizedImg.crossOrigin = 'anonymous';

  return optimizedImg;
};