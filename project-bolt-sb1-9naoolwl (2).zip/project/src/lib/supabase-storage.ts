import { supabase } from './supabase';

export const uploadLogo = async (file: File) => {
  try {
    const fileExt = file.name.split('.').pop();
    const fileName = `logo.${fileExt}`;
    const { error } = await supabase.storage
      .from('assets')
      .upload(fileName, file, {
        upsert: true,
        cacheControl: '3600',
        contentType: file.type
      });

    if (error) throw error;

    const { data: { publicUrl } } = supabase.storage
      .from('assets')
      .getPublicUrl(fileName);

    return publicUrl;
  } catch (error) {
    console.error('Error uploading logo:', error);
    throw error;
  }
};

export const getLogoUrl = () => {
  const { data: { publicUrl } } = supabase.storage
    .from('assets')
    .getPublicUrl('logo.png');
  return publicUrl;
};