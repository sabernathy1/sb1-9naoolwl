self.onmessage = (e: MessageEvent) => {
  const imageData = e.data;
  
  // Process image data
  const processedData = processImage(imageData);
  
  self.postMessage(processedData);
};

function processImage(imageData: ImageData): ImageData {
  const { data, width, height } = imageData;
  const processed = new Uint8ClampedArray(data.length);

  // Apply optimizations
  for (let i = 0; i < data.length; i += 4) {
    processed[i] = data[i];       // R
    processed[i + 1] = data[i + 1]; // G
    processed[i + 2] = data[i + 2]; // B
    processed[i + 3] = data[i + 3]; // A
  }

  return new ImageData(processed, width, height);
}

export {};