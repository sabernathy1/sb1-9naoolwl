-- Update product images with high-quality Unsplash photos
UPDATE products
SET 
  image_url = CASE name
    WHEN 'Classic Custom T-Shirt' THEN 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Premium Hoodie' THEN 'https://images.unsplash.com/photo-1556821840-5a7f7ea7c06c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Custom Baseball Cap' THEN 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Performance Athletic Shirt' THEN 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Zip-Up Hoodie' THEN 'https://images.unsplash.com/photo-1614031679232-0dae776a72ee?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Beanie' THEN 'https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Limited Edition Artist Series Tee' THEN 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Premium Embroidered Hoodie' THEN 'https://images.unsplash.com/photo-1625024573124-57a3efa69d7e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Vintage Wash T-Shirt' THEN 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Tech Fleece Hoodie' THEN 'https://images.unsplash.com/photo-1509942774463-acf339cf87d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Custom Phone Case' THEN 'https://images.unsplash.com/photo-1586953208448-b95a79798f07?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Eco-Friendly Tote Bag' THEN 'https://images.unsplash.com/photo-1597484662317-9bd7bdda2907?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Premium Long Sleeve Tee' THEN 'https://images.unsplash.com/photo-1618354691792-d1d42acfd860?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Winter Collection Hoodie' THEN 'https://images.unsplash.com/photo-1604644401890-0bd678c83788?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Custom Laptop Sleeve' THEN 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    ELSE image_url
  END,
  image_url_front = CASE name
    WHEN 'Classic Custom T-Shirt' THEN 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Premium Hoodie' THEN 'https://images.unsplash.com/photo-1556821840-5a7f7ea7c06c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Custom Baseball Cap' THEN 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Performance Athletic Shirt' THEN 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Zip-Up Hoodie' THEN 'https://images.unsplash.com/photo-1614031679232-0dae776a72ee?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Beanie' THEN 'https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Limited Edition Artist Series Tee' THEN 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Premium Embroidered Hoodie' THEN 'https://images.unsplash.com/photo-1625024573124-57a3efa69d7e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Vintage Wash T-Shirt' THEN 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Tech Fleece Hoodie' THEN 'https://images.unsplash.com/photo-1509942774463-acf339cf87d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Custom Phone Case' THEN 'https://images.unsplash.com/photo-1586953208448-b95a79798f07?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Eco-Friendly Tote Bag' THEN 'https://images.unsplash.com/photo-1597484662317-9bd7bdda2907?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Premium Long Sleeve Tee' THEN 'https://images.unsplash.com/photo-1618354691792-d1d42acfd860?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Winter Collection Hoodie' THEN 'https://images.unsplash.com/photo-1604644401890-0bd678c83788?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    WHEN 'Custom Laptop Sleeve' THEN 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80'
    ELSE image_url_front
  END;

-- Update preview_images array for each product
UPDATE products
SET preview_images = ARRAY[image_url_front];