import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  server: {
    hmr: {
      overlay: false, // Disable the overlay for better error handling
    },
  },
  plugins: [react()],
  optimizeDeps: {
    include: ['fabric'],
    esbuildOptions: {
      target: 'es2020',
    },
  },
  build: {
    commonjsOptions: {
      include: [/fabric/, /node_modules/],
      transformMixedEsModules: true,
    },
    target: 'es2020',
    sourcemap: true,
  },
});
