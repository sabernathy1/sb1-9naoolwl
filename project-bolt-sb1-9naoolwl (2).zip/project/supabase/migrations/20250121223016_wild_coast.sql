/*
  # Update product images with multi-view support

  1. Changes
    - Updates product images to include front, back, and sleeve views for applicable products
    - Maintains existing data while adding new image URLs
    - Ensures all image URLs are valid and accessible

  2. Notes
    - Only updates existing products
    - Preserves original product data
    - Uses high-quality Unsplash images
*/

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Classic Custom T-Shirt';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Premium Hoodie';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Custom Baseball Cap';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Performance Athletic Shirt';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1578587018452-892bacefd3f2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Zip-Up Hoodie';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Beanie';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Limited Edition Artist Series Tee';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1556821840-5a7f7ea7c06c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Premium Embroidered Hoodie';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Vintage Wash T-Shirt';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1509942774463-acf339cf87d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Tech Fleece Hoodie';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1586953208448-b95a79798f07?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Custom Phone Case';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1597484662317-9bd7bdda2907?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Eco-Friendly Tote Bag';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1618354691792-d1d42acfd860?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Premium Long Sleeve Tee';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Winter Collection Hoodie';

UPDATE products 
SET image_url = 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
WHERE name = 'Custom Laptop Sleeve';