-- Add image_url column to product_variants table
ALTER TABLE product_variants
ADD COLUMN image_url text;

-- Update existing variants with color-specific images
UPDATE product_variants
SET image_url = 
  CASE 
    WHEN (attributes->>'color') = 'Black' THEN REPLACE(p.image_url, '.jpg', '-black.jpg')
    WHEN (attributes->>'color') = 'White' THEN REPLACE(p.image_url, '.jpg', '-white.jpg')
    WHEN (attributes->>'color') = 'Navy' THEN REPLACE(p.image_url, '.jpg', '-navy.jpg')
    WHEN (attributes->>'color') = 'Gray' THEN REPLACE(p.image_url, '.jpg', '-gray.jpg')
    WHEN (attributes->>'color') = 'Red' THEN REPLACE(p.image_url, '.jpg', '-red.jpg')
    ELSE p.image_url
  END
FROM products p
WHERE product_variants.product_id = p.id;

-- Add NOT NULL constraint after populating data
ALTER TABLE product_variants
ALTER COLUMN image_url SET NOT NULL;