/*
  # User Addresses Schema Update
  
  1. Changes
    - Creates user_addresses table if it doesn't exist
    - Adds RLS policies for CRUD operations
    - Adds trigger for default address management
    - Adds performance index
  
  2. Security
    - Enables RLS
    - Adds policies for authenticated users to manage their addresses
    - Uses SECURITY DEFINER for trigger function
*/

-- Create user_addresses table if it doesn't exist
CREATE TABLE IF NOT EXISTS public.user_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  name text NOT NULL,
  street text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  postal_code text NOT NULL,
  country text NOT NULL,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT unique_default_address UNIQUE (user_id, is_default) 
    DEFERRABLE INITIALLY DEFERRED
);

-- Enable RLS
ALTER TABLE public.user_addresses ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can view own addresses" ON public.user_addresses;
  DROP POLICY IF EXISTS "Users can create own addresses" ON public.user_addresses;
  DROP POLICY IF EXISTS "Users can update own addresses" ON public.user_addresses;
  DROP POLICY IF EXISTS "Users can delete own addresses" ON public.user_addresses;
EXCEPTION
  WHEN undefined_object THEN
    NULL;
END $$;

-- Create policies
CREATE POLICY "Users can view own addresses"
  ON public.user_addresses
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own addresses"
  ON public.user_addresses
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own addresses"
  ON public.user_addresses
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own addresses"
  ON public.user_addresses
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Drop existing function and trigger if they exist
DROP TRIGGER IF EXISTS set_default_address ON public.user_addresses;
DROP FUNCTION IF EXISTS handle_default_address();

-- Create function to handle default address logic
CREATE OR REPLACE FUNCTION handle_default_address()
RETURNS trigger AS $$
BEGIN
  IF NEW.is_default THEN
    UPDATE public.user_addresses
    SET is_default = false
    WHERE user_id = NEW.user_id
      AND id != NEW.id
      AND is_default = true;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for default address management
CREATE TRIGGER set_default_address
  BEFORE INSERT OR UPDATE ON public.user_addresses
  FOR EACH ROW
  EXECUTE FUNCTION handle_default_address();

-- Drop existing index if it exists
DROP INDEX IF EXISTS idx_user_addresses_user_id;

-- Create index for faster lookups
CREATE INDEX idx_user_addresses_user_id ON public.user_addresses(user_id);