/*
  # Add product views

  1. Changes
    - Add new columns for different product views:
      - image_url_front
      - image_url_back
      - image_url_left_sleeve
      - image_url_right_sleeve
    - Migrate existing image_url data to image_url_front
    - Update sample data with view-specific images
  
  2. Notes
    - Maintains backward compatibility by keeping image_url
    - Uses safe column addition with default values
*/

-- Add new columns for product views
ALTER TABLE products
ADD COLUMN IF NOT EXISTS image_url_front text,
ADD COLUMN IF NOT EXISTS image_url_back text,
ADD COLUMN IF NOT EXISTS image_url_left_sleeve text,
ADD COLUMN IF NOT EXISTS image_url_right_sleeve text;

-- Migrate existing image_url data to image_url_front
UPDATE products
SET image_url_front = image_url
WHERE image_url_front IS NULL;

-- Update sample data with view-specific images
UPDATE products
SET
  image_url_back = REPLACE(image_url, '.jpg', '-back.jpg'),
  image_url_left_sleeve = 
    CASE 
      WHEN category IN ('T-Shirts', 'Hoodies') 
      THEN REPLACE(image_url, '.jpg', '-left-sleeve.jpg')
      ELSE NULL
    END,
  image_url_right_sleeve = 
    CASE 
      WHEN category IN ('T-Shirts', 'Hoodies') 
      THEN REPLACE(image_url, '.jpg', '-right-sleeve.jpg')
      ELSE NULL
    END
WHERE category IN ('T-Shirts', 'Hoodies', 'Accessories');