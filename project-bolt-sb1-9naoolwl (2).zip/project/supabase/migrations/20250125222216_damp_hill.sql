-- Add new columns for product views
ALTER TABLE products
ADD COLUMN IF NOT EXISTS image_url_front text,
ADD COLUMN IF NOT EXISTS image_url_back text,
ADD COLUMN IF NOT EXISTS image_url_left_sleeve text,
ADD COLUMN IF NOT EXISTS image_url_right_sleeve text,
ADD COLUMN IF NOT EXISTS available_placements text[] DEFAULT ARRAY['front']::text[];

-- Migrate existing image_url data to image_url_front
UPDATE products
SET image_url_front = image_url
WHERE image_url_front IS NULL;

-- Update available placements and view-specific images based on category
UPDATE products
SET
  image_url_back = REPLACE(image_url, '.jpg', '-back.jpg'),
  image_url_left_sleeve = 
    CASE 
      WHEN category IN ('T-Shirts', 'Hoodies') 
      THEN REPLACE(image_url, '.jpg', '-left-sleeve.jpg')
      ELSE NULL
    END,
  image_url_right_sleeve = 
    CASE 
      WHEN category IN ('T-Shirts', 'Hoodies') 
      THEN REPLACE(image_url, '.jpg', '-right-sleeve.jpg')
      ELSE NULL
    END,
  available_placements = 
    CASE 
      WHEN category IN ('T-Shirts', 'Hoodies') 
      THEN ARRAY['front', 'back', 'left-sleeve', 'right-sleeve']::text[]
      WHEN category = 'Accessories' 
      THEN ARRAY['front', 'back']::text[]
      ELSE ARRAY['front']::text[]
    END
WHERE category IN ('T-Shirts', 'Hoodies', 'Accessories');

-- Create an index on the category column for faster lookups
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);

-- Add a check constraint to ensure valid placements
ALTER TABLE products
ADD CONSTRAINT valid_placements CHECK (
  available_placements <@ ARRAY['front', 'back', 'left-sleeve', 'right-sleeve']::text[]
);