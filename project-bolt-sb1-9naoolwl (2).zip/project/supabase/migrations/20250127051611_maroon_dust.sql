/*
  # Fix RLS policies for users table

  1. Changes
    - Drop existing policies to start fresh
    - Create simplified policies that avoid recursion
    - Add proper admin access controls
*/

-- Drop all existing policies
DROP POLICY IF EXISTS "Users can view own profile" ON users;
DROP POLICY IF EXISTS "Users can update own profile" ON users;
DROP POLICY IF EXISTS "Admins can update any profile" ON users;
DROP POLICY IF EXISTS "System can create user profiles" ON users;

-- Create new simplified policies
CREATE POLICY "Users can view own profile"
  ON users
  FOR SELECT
  USING (
    auth.uid() = id OR 
    is_admin = true
  );

CREATE POLICY "Users can update own profile"
  ON users
  FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Admins can update any profile"
  ON users
  FOR UPDATE
  USING (is_admin = true)
  WITH CHECK (is_admin = true);

CREATE POLICY "System can create user profiles"
  ON users
  FOR INSERT
  WITH CHECK (true);

-- Ensure RLS is enabled
ALTER TABLE users ENABLE ROW LEVEL SECURITY;