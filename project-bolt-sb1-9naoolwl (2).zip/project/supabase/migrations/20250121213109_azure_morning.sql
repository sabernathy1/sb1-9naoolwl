/*
  # Add Gallery Designs

  1. Changes
    - Add sample designs to the gallery_images table
    - Include various categories and styles
*/

INSERT INTO gallery_images (url, watermarked_url, category)
VALUES
  (
    'https://images.unsplash.com/photo-1516876437184-593fda40c7ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1516876437184-593fda40c7ce?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Abstract'
  ),
  (
    'https://images.unsplash.com/photo-1534447677768-be436bb09401?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1534447677768-be436bb09401?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Nature'
  ),
  (
    'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Typography'
  ),
  (
    'https://images.unsplash.com/photo-1563089145-599997674d42?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1563089145-599997674d42?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Animals'
  ),
  (
    'https://images.unsplash.com/photo-1608501947097-86951ad73fea?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1608501947097-86951ad73fea?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Sports'
  ),
  (
    'https://images.unsplash.com/photo-1578252594952-848cf22a540c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'https://images.unsplash.com/photo-1578252594952-848cf22a540c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Music'
  );