/*
  # Add sample products

  1. New Data
    - Adds initial product catalog with various customizable apparel items
    - Each product includes name, description, price, category, and image
  2. Categories
    - T-Shirts
    - Hoodies
    - Accessories
*/

INSERT INTO products (name, description, price, image_url, category, customizable)
VALUES
  (
    'Classic Custom T-Shirt',
    'Premium cotton t-shirt perfect for custom designs. Available in multiple sizes and colors.',
    29.99,
    'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'T-Shirts',
    true
  ),
  (
    'Premium Hoodie',
    'Cozy and durable hoodie made from high-quality materials. Perfect canvas for your custom designs.',
    49.99,
    'https://images.unsplash.com/photo-1556821840-3a63f95609a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Hoodies',
    true
  ),
  (
    'Custom Baseball Cap',
    'Adjustable cotton baseball cap. Add your design or text for a personalized look.',
    24.99,
    'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Accessories',
    true
  ),
  (
    'Performance Athletic Shirt',
    'Moisture-wicking athletic shirt perfect for sports and active lifestyle. Customizable with your design.',
    34.99,
    'https://images.unsplash.com/photo-1581655353564-df123a1eb820?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'T-Shirts',
    true
  ),
  (
    'Zip-Up Hoodie',
    'Modern zip-up hoodie with premium stitching and comfortable fit. Ready for your custom design.',
    54.99,
    'https://images.unsplash.com/photo-1578587018452-892bacefd3f2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Hoodies',
    true
  ),
  (
    'Beanie',
    'Warm and stylish beanie that can be customized with your unique design or text.',
    19.99,
    'https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Accessories',
    true
  );