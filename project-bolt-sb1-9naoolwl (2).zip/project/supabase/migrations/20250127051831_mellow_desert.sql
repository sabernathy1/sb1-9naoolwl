/*
  # Add cascade delete to product variants

  1. Changes
    - Drop existing foreign key constraint
    - Add new constraint with CASCADE DELETE
    - This ensures variants are automatically deleted when a product is deleted
*/

-- Drop existing foreign key constraint
ALTER TABLE product_variants
DROP CONSTRAINT IF EXISTS product_variants_product_id_fkey;

-- Add new constraint with CASCADE DELETE
ALTER TABLE product_variants
ADD CONSTRAINT product_variants_product_id_fkey
FOREIGN KEY (product_id)
REFERENCES products(id)
ON DELETE CASCADE;