-- Add preview_images column to products table
ALTER TABLE products
ADD COLUMN IF NOT EXISTS preview_images text[] DEFAULT ARRAY[]::text[];

-- Update preview images for existing products
WITH product_images AS (
  SELECT id,
    ARRAY[
      image_url,
      image_url_back,
      image_url_left_sleeve,
      image_url_right_sleeve
    ] AS images
  FROM products
  WHERE category IN ('T-Shirts', 'Hoodies', 'Accessories')
)
UPDATE products p
SET preview_images = (
  SELECT ARRAY(
    SELECT unnest
    FROM unnest(pi.images) AS unnest
    WHERE unnest IS NOT NULL
  )
)
FROM product_images pi
WHERE p.id = pi.id;

-- Add check constraint to ensure preview_images is not empty
ALTER TABLE products
ADD CONSTRAINT preview_images_not_empty CHECK (
  array_length(preview_images, 1) > 0
);