/*
  # Add Service Products Schema

  1. New Tables
    - `service_products`
      - `id` (uuid, primary key)
      - `service_id` (text, references service type)
      - `name` (text)
      - `description` (text)
      - `base_price` (numeric)
      - `options` (jsonb)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `service_products` table
    - Add policy for public read access
*/

-- Create service products table
CREATE TABLE service_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id text NOT NULL,
  name text NOT NULL,
  description text,
  base_price numeric NOT NULL CHECK (base_price >= 0),
  options jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE service_products ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can read service products"
  ON service_products
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Insert sample service products
INSERT INTO service_products (service_id, name, description, base_price, options) VALUES
(
  'press-only',
  'Basic Press Service',
  'Professional heat press service for your pre-made designs',
  15.00,
  '[
    {
      "name": "Location Count",
      "type": "select",
      "required": true,
      "options": [
        {"label": "Single Location", "value": "single", "price": 0},
        {"label": "Two Locations", "value": "double", "price": 10},
        {"label": "Three Locations", "value": "triple", "price": 20}
      ]
    },
    {
      "name": "Service Type",
      "type": "select",
      "required": true,
      "options": [
        {"label": "In-Store Service", "value": "in-store", "price": 0},
        {"label": "On-Site Service", "value": "on-site", "price": 50}
      ]
    },
    {
      "name": "Turnaround Time",
      "type": "select",
      "required": true,
      "options": [
        {"label": "Standard (2-3 days)", "value": "standard", "price": 0},
        {"label": "Rush (Next Day)", "value": "rush", "price": 25},
        {"label": "Same Day", "value": "same-day", "price": 40}
      ]
    }
  ]'::jsonb
),
(
  'design-shop',
  'Custom Design Package',
  'Professional design service with unlimited revisions',
  49.99,
  '[
    {
      "name": "Design Complexity",
      "type": "select",
      "required": true,
      "options": [
        {"label": "Basic Design", "value": "basic", "price": 0},
        {"label": "Standard Design", "value": "standard", "price": 25},
        {"label": "Complex Design", "value": "complex", "price": 50}
      ]
    },
    {
      "name": "Turnaround Time",
      "type": "select",
      "required": true,
      "options": [
        {"label": "Standard (3-5 days)", "value": "standard", "price": 0},
        {"label": "Rush (2 days)", "value": "rush", "price": 30},
        {"label": "Same Day", "value": "same-day", "price": 50}
      ]
    },
    {
      "name": "File Format",
      "type": "select",
      "required": true,
      "options": [
        {"label": "Basic (JPG/PNG)", "value": "basic", "price": 0},
        {"label": "Vector (AI/EPS)", "value": "vector", "price": 20}
      ]
    }
  ]'::jsonb
),
(
  'print-press',
  'Print & Press Service',
  'Full-service printing and pressing for your custom designs',
  25.00,
  '[
    {
      "name": "Print Method",
      "type": "select",
      "required": true,
      "options": [
        {"label": "Heat Transfer", "value": "heat-transfer", "price": 0},
        {"label": "DTG Printing", "value": "dtg", "price": 10},
        {"label": "Vinyl", "value": "vinyl", "price": 5}
      ]
    },
    {
      "name": "Size",
      "type": "select",
      "required": true,
      "options": [
        {"label": "Small (up to 5\"x5\")", "value": "small", "price": 0},
        {"label": "Medium (up to 10\"x10\")", "value": "medium", "price": 10},
        {"label": "Large (up to 15\"x15\")", "value": "large", "price": 20}
      ]
    },
    {
      "name": "Turnaround Time",
      "type": "select",
      "required": true,
      "options": [
        {"label": "Standard (2-3 days)", "value": "standard", "price": 0},
        {"label": "Rush (Next Day)", "value": "rush", "price": 25},
        {"label": "Same Day", "value": "same-day", "price": 40}
      ]
    }
  ]'::jsonb
);