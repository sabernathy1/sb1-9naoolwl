/*
  # Add Product Variants Support

  1. New Tables
    - `product_variants`
      - `id` (uuid, primary key)
      - `product_id` (uuid, references products)
      - `name` (text)
      - `sku` (text)
      - `price` (numeric)
      - `stock` (integer)
      - `attributes` (jsonb)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `product_variants` table
    - Add policy for public read access
*/

-- Create product variants table
CREATE TABLE product_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products NOT NULL,
  name text NOT NULL,
  sku text UNIQUE NOT NULL,
  price numeric NOT NULL CHECK (price >= 0),
  stock integer NOT NULL DEFAULT 0 CHECK (stock >= 0),
  attributes jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE product_variants ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can read product variants"
  ON product_variants
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Create indexes
CREATE INDEX idx_product_variants_product_id ON product_variants(product_id);
CREATE INDEX idx_product_variants_sku ON product_variants(sku);

-- Add sample variants for existing products
INSERT INTO product_variants (product_id, name, sku, price, stock, attributes)
SELECT 
  p.id,
  p.name || ' - ' || size || ' - ' || color,
  p.id || '-' || size || '-' || color,
  p.price,
  100,
  jsonb_build_object(
    'size', size,
    'color', color
  )
FROM products p
CROSS JOIN (
  SELECT unnest(ARRAY['XS', 'S', 'M', 'L', 'XL', 'XXL']) as size
) sizes
CROSS JOIN (
  SELECT unnest(ARRAY['Black', 'White', 'Navy', 'Gray', 'Red']) as color
) colors
WHERE p.category IN ('T-Shirts', 'Hoodies');

-- Add variants for accessories (no sizes, just colors)
INSERT INTO product_variants (product_id, name, sku, price, stock, attributes)
SELECT 
  p.id,
  p.name || ' - ' || color,
  p.id || '-' || color,
  p.price,
  100,
  jsonb_build_object(
    'color', color
  )
FROM products p
CROSS JOIN (
  SELECT unnest(ARRAY['Black', 'White', 'Navy', 'Gray', 'Red']) as color
) colors
WHERE p.category = 'Accessories';