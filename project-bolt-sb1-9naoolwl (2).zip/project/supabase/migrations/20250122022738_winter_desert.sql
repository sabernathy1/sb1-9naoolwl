/*
  # Create user addresses table

  1. New Tables
    - `user_addresses`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `name` (text, for address label like "Home" or "Work")
      - `street` (text)
      - `city` (text)
      - `state` (text)
      - `postal_code` (text)
      - `country` (text)
      - `is_default` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on user_addresses table
    - Add policies for users to manage their own addresses
    - Ensure foreign key constraint to auth.users
*/

-- Create user_addresses table
CREATE TABLE IF NOT EXISTS public.user_addresses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  name text NOT NULL,
  street text NOT NULL,
  city text NOT NULL,
  state text NOT NULL,
  postal_code text NOT NULL,
  country text NOT NULL,
  is_default boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT unique_default_address UNIQUE (user_id, is_default) 
    DEFERRABLE INITIALLY DEFERRED
);

-- Enable RLS
ALTER TABLE public.user_addresses ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view own addresses"
  ON public.user_addresses
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own addresses"
  ON public.user_addresses
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own addresses"
  ON public.user_addresses
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own addresses"
  ON public.user_addresses
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create function to handle default address logic
CREATE OR REPLACE FUNCTION handle_default_address()
RETURNS trigger AS $$
BEGIN
  IF NEW.is_default THEN
    UPDATE public.user_addresses
    SET is_default = false
    WHERE user_id = NEW.user_id
      AND id != NEW.id
      AND is_default = true;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for default address management
CREATE TRIGGER set_default_address
  BEFORE INSERT OR UPDATE ON public.user_addresses
  FOR EACH ROW
  EXECUTE FUNCTION handle_default_address();

-- Create index for faster lookups
CREATE INDEX idx_user_addresses_user_id ON public.user_addresses(user_id);

-- Insert sample address for testing
INSERT INTO public.user_addresses (
  user_id,
  name,
  street,
  city,
  state,
  postal_code,
  country,
  is_default
) VALUES (
  '8165c687-8ff5-47f2-aad2-12ffc2d73b4a',
  'Home',
  '123 Main St',
  'Springfield',
  'IL',
  '62701',
  'United States',
  true
);