/*
  # Add product variants data
  
  This migration adds sample variant data for existing products.
  
  1. Data Changes
    - Adds variants for T-Shirts and Hoodies with sizes and colors
    - Adds variants for Accessories with colors only
    - Sets initial stock levels and pricing
*/

-- Clear existing variants
TRUNCATE product_variants CASCADE;

-- Add sample variants for existing products
INSERT INTO product_variants (product_id, name, sku, price, stock, attributes)
SELECT 
  p.id,
  p.name || ' - ' || size || ' - ' || color,
  p.id || '-' || size || '-' || color,
  p.price,
  100,
  jsonb_build_object(
    'size', size,
    'color', color
  )
FROM products p
CROSS JOIN (
  SELECT unnest(ARRAY['XS', 'S', 'M', 'L', 'XL', 'XXL']) as size
) sizes
CROSS JOIN (
  SELECT unnest(ARRAY['Black', 'White', 'Navy', 'Gray', 'Red']) as color
) colors
WHERE p.category IN ('T-Shirts', 'Hoodies');

-- Add variants for accessories (no sizes, just colors)
INSERT INTO product_variants (product_id, name, sku, price, stock, attributes)
SELECT 
  p.id,
  p.name || ' - ' || color,
  p.id || '-' || color,
  p.price,
  100,
  jsonb_build_object(
    'color', color
  )
FROM products p
CROSS JOIN (
  SELECT unnest(ARRAY['Black', 'White', 'Navy', 'Gray', 'Red']) as color
) colors
WHERE p.category = 'Accessories';