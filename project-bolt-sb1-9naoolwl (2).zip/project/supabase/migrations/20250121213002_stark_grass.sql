/*
  # Add More Products

  1. Changes
    - Add additional products to the products table including:
      - Limited Edition items
      - Seasonal collections
      - Premium customizable products
*/

INSERT INTO products (name, description, price, image_url, category, customizable)
VALUES
  (
    'Limited Edition Artist Series Tee',
    'Exclusive t-shirt featuring unique artwork from local artists. Each piece is numbered and comes with a certificate of authenticity.',
    39.99,
    'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'T-Shirts',
    true
  ),
  (
    'Premium Embroidered Hoodie',
    'Luxury hoodie with premium embroidery options. Made from organic cotton and recycled materials.',
    69.99,
    'https://images.unsplash.com/photo-1556821840-5a7f7ea7c06c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Hoodies',
    true
  ),
  (
    'Vintage Wash T-Shirt',
    'Pre-washed for extra softness, this vintage-style tee is perfect for retro designs.',
    34.99,
    'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'T-Shirts',
    true
  ),
  (
    'Tech Fleece Hoodie',
    'Modern athletic hoodie with moisture-wicking technology and sleek design.',
    79.99,
    'https://images.unsplash.com/photo-1509942774463-acf339cf87d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Hoodies',
    true
  ),
  (
    'Custom Phone Case',
    'Durable phone case that can be personalized with your favorite design or photo.',
    24.99,
    'https://images.unsplash.com/photo-1586953208448-b95a79798f07?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Accessories',
    true
  ),
  (
    'Eco-Friendly Tote Bag',
    'Sustainable canvas tote bag perfect for custom designs and everyday use.',
    29.99,
    'https://images.unsplash.com/photo-1597484662317-9bd7bdda2907?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Accessories',
    true
  ),
  (
    'Premium Long Sleeve Tee',
    'High-quality long sleeve t-shirt with reinforced stitching and premium fabric.',
    39.99,
    'https://images.unsplash.com/photo-1618354691792-d1d42acfd860?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'T-Shirts',
    true
  ),
  (
    'Winter Collection Hoodie',
    'Extra warm winter hoodie with sherpa lining and drawstring hood.',
    89.99,
    'https://images.unsplash.com/photo-1556821840-3a63f95609a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Hoodies',
    true
  ),
  (
    'Custom Laptop Sleeve',
    'Protective neoprene laptop sleeve available in multiple sizes with customizable design.',
    34.99,
    'https://images.unsplash.com/photo-1603302576837-37561b2e2302?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    'Accessories',
    true
  );